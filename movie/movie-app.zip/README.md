# CineMaster Pro - Movie Management System

A full-stack movie management application with user authentication, collection management, and review system.

## Features

- 🎬 Movie Discovery: Search and browse movies with detailed information
- 👤 User Authentication: Secure registration and login system
- 📚 Collections: Create and manage personal movie collections
- ⭐ Reviews: Rate and review movies
- 🌐 Responsive Design: Works on all devices
- 🌙 Dark Mode: Comfortable viewing experience

## Technology Stack

### Backend
- Express.js
- PostgreSQL
- JWT Authentication
- TMDB API Integration

### Frontend
- React 18
- Vite
- Responsive CSS

## Database Enhancements

This application now includes advanced database functions and triggers for improved data integrity and performance:

### Functions
1. `update_updated_at_column()` - Automatically updates timestamps
2. `calculate_movie_average_rating()` - Calculates average movie ratings
3. `get_movie_review_count()` - Counts reviews for a movie
4. `update_movie_rating()` - Updates movie ratings when reviews change
5. `prevent_duplicate_collection_movies()` - Prevents duplicate movies in collections

### Triggers
1. Automatic timestamp updates for all tables
2. Real-time movie rating calculations
3. Duplicate prevention in collections
4. Performance indexes for common queries

## Setup Instructions

1. Clone the repository
2. Install dependencies:
   ```bash
   cd movie-management-backend && npm install
   cd ../movie-management-frontend && npm install
   ```
3. Set up environment variables in both `.env` files
4. Create PostgreSQL database:
   ```sql
   CREATE DATABASE movie_management;
   ```
5. Run database setup:
   ```bash
   cd movie-management-backend
   node seed.js
   ```
6. Start the servers:
   ```bash
   # Terminal 1
   cd movie-management-backend && npm start
   
   # Terminal 2
   cd movie-management-frontend && npm run dev
   ```

## API Endpoints

- `GET /api/movies` - Get all movies
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/collections` - Get user collections
- `POST /api/reviews` - Add movie review

## Deployment

The application can be deployed to cloud services like Render (backend), Netlify (frontend), and Neon (database) for a completely free hosting solution.