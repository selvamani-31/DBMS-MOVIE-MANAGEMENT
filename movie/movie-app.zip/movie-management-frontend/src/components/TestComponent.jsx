import React from 'react';

const TestComponent = () => {
  return (
    <div style={{ 
      color: 'white', 
      padding: '20px', 
      textAlign: 'center',
      backgroundColor: '#1a1a1a',
      minHeight: '100vh'
    }}>
      <h1>Test Component</h1>
      <p>If you can see this, the React app is working!</p>
    </div>
  );
};

export default TestComponent;