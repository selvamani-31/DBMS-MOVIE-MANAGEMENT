import React, { useState } from 'react';
import MovieDetailsModal from './MovieDetailsModal';

const MovieCard = ({ movie, onDelete, canDelete, onAddToCollection, collections, onRemoveFromCollection, showRemoveButton }) => {
  const [showDetails, setShowDetails] = useState(false);
  const [showCollectionMenu, setShowCollectionMenu] = useState(false);

  const handleDelete = () => {
    if (window.confirm(`🗑️ Are you sure you want to delete "${movie.title}"?`)) {
      onDelete(movie.movie_id);
    }
  };

  const handleShowDetails = () => {
    setShowDetails(true);
  };

  const handleCloseDetails = () => {
    setShowDetails(false);
  };

  const handleAddToCollectionClick = (e) => {
    e.stopPropagation();
    if (collections && collections.length > 0) {
      setShowCollectionMenu(!showCollectionMenu);
    } else {
      // If no collections exist, you might want to prompt user to create one
      alert('Please create a collection first!');
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Generate a placeholder image with the movie title
  const generatePlaceholderImage = (title) => {
    // Create a simple placeholder with the first letter of the title
    const firstLetter = title ? title.charAt(0).toUpperCase() : 'M';
    return `https://placehold.co/300x450/2D3748/FFFFFF?text=${encodeURIComponent(firstLetter)}`;
  };

  // Determine the poster URL to use
  const getPosterUrl = () => {
    if (movie.poster_url && movie.poster_url.trim() !== '') {
      // If it's a full URL, use it directly
      if (movie.poster_url.startsWith('http')) {
        return movie.poster_url;
      }
      // If it's a relative path, prepend the base URL
      return `http://localhost:5000${movie.poster_url}`;
    }
    // Use generated placeholder
    return generatePlaceholderImage(movie.title);
  };

  // For debugging - you can remove this in production
  const posterUrl = getPosterUrl();

  // Check if this should be a featured card (for popular movies)
  const isFeatured = movie.rating >= 8.0;

  return (
    <>
      <div className={`movie-card ${isFeatured ? 'featured' : ''}`} onClick={handleShowDetails}>
        <div className="movie-poster">
          <img 
            src={posterUrl}
            alt={movie.title}
            onError={(e) => {
              console.log(`Failed to load image for ${movie.title}, using placeholder`);
              // If the image fails to load, use a simple placeholder
              e.target.src = generatePlaceholderImage(movie.title);
            }}
            onLoad={(e) => {
              console.log(`Successfully loaded image for ${movie.title}`);
            }}
            loading="lazy"
          />
          <div className="movie-overlay">
            <div className="movie-rating">
              ⭐ {movie.rating || 'N/A'}
            </div>
            <div className="card-actions">
              {canDelete && !showRemoveButton && (
                <button 
                  className="delete-btn"
                  onClick={(e) => {
                    e.stopPropagation(); // Prevent opening details when clicking delete
                    handleDelete();
                  }}
                  title="Delete movie"
                  aria-label={`Delete ${movie.title}`}
                >
                  🗑️
                </button>
              )}
              {showRemoveButton && (
                <button 
                  className="delete-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    onRemoveFromCollection();
                  }}
                  title="Remove from collection"
                  aria-label={`Remove ${movie.title} from collection`}
                >
                  🗑️
                </button>
              )}
              {canDelete && onAddToCollection && !showRemoveButton && (
                <button 
                  className="collection-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleAddToCollectionClick(e);
                  }}
                  title="Add to collection"
                  aria-label={`Add ${movie.title} to collection`}
                >
                  📚
                </button>
              )}
            </div>
          </div>
        </div>
        
        <div className="movie-info">
          <h3 className="movie-title">{movie.title}</h3>
          <p className="movie-description">
            {movie.description || 'No description available.'}
          </p>
          
          <div className="movie-details">
            <div className="detail">
              <span className="label">Duration:</span>
              <span className="value">{movie.duration_minutes} min</span>
            </div>
            <div className="detail">
              <span className="label">Released:</span>
              <span className="value">{formatDate(movie.release_date)}</span>
            </div>
            {movie.genres && movie.genres.length > 0 && (
              <div className="detail">
                <span className="label">Genres:</span>
                <span className="value">
                  {movie.genres.slice(0, 2).join(', ')}
                  {movie.genres.length > 2 && '...'}
                </span>
              </div>
            )}
          </div>

          {movie.actors && movie.actors.length > 0 && (
            <div className="movie-cast">
              <span className="cast-label">Starring:</span>
              <div className="cast-list">
                {movie.actors.slice(0, 3).map((actor, index) => (
                  <span key={index} className="cast-member">{actor}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Collection Menu */}
      {showCollectionMenu && collections && (
        <div className="collection-menu" onClick={(e) => e.stopPropagation()}>
          <div className="collection-menu-header">
            <h4>Add to Collection</h4>
            <button 
              className="close-menu-btn" 
              onClick={() => setShowCollectionMenu(false)}
            >
              ×
            </button>
          </div>
          <div className="collection-menu-list">
            {collections.map((collection) => (
              <button
                key={collection.collection_id}
                className="collection-menu-item"
                onClick={() => {
                  onAddToCollection(collection.collection_id);
                  setShowCollectionMenu(false);
                }}
              >
                {collection.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {showDetails && (
        <MovieDetailsModal 
          movie={movie} 
          onClose={handleCloseDetails} 
        />
      )}
    </>
  );
};

export default MovieCard;