import React, { useState, useEffect } from 'react';
import { movieAPI, reviewAPI } from '../services/api';

const MovieDetailsModal = ({ movie, onClose }) => {
  const [movieDetails, setMovieDetails] = useState(movie);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('overview');
  const [relatedMovies, setRelatedMovies] = useState([]);
  const [reviews, setReviews] = useState([]);
  const [userReview, setUserReview] = useState(null);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [isAddingReview, setIsAddingReview] = useState(false);

  useEffect(() => {
    // Fetch detailed movie information when component mounts
    fetchMovieDetails();
    fetchRelatedMovies();
    fetchReviews();
    fetchUserReview();
  }, [movie.movie_id]);

  const fetchMovieDetails = async () => {
    if (!movie.movie_id) return;
    
    setLoading(true);
    setError('');
    
    try {
      const response = await movieAPI.getById(movie.movie_id);
      console.log('Movie details response:', response.data); // Debug log
      setMovieDetails(response.data.data);
    } catch (err) {
      setError('Failed to load detailed movie information');
      console.error('Error fetching movie details:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchRelatedMovies = async () => {
    if (!movie.movie_id) return;
    
    try {
      const response = await movieAPI.getRelated(movie.movie_id);
      console.log('Related movies response:', response.data); // Debug log
      setRelatedMovies(response.data.data);
    } catch (err) {
      console.error('Error fetching related movies:', err);
      // Don't show error to user for related movies, just leave it empty
    }
  };

  const fetchReviews = async () => {
    if (!movie.movie_id) return;
    
    try {
      const response = await reviewAPI.getMovieReviews(movie.movie_id);
      setReviews(response.data.data);
    } catch (err) {
      console.error('Error fetching reviews:', err);
    }
  };

  const fetchUserReview = async () => {
    if (!movie.movie_id) return;
    
    try {
      const response = await reviewAPI.getUserReview(movie.movie_id);
      
      if (response.data.data) {
        setUserReview(response.data.data);
        setReviewForm({
          rating: response.data.data.rating,
          comment: response.data.data.comment
        });
      }
    } catch (err) {
      console.error('Error fetching user review:', err);
    }
  };

  const handleAddReview = async (e) => {
    e.preventDefault();
    setIsAddingReview(true);
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Please login to add a review');
        setIsAddingReview(false);
        return;
      }
      
      console.log('Adding review with data:', { movieId: movie.movie_id, reviewForm });
      const response = await reviewAPI.addReview(movie.movie_id, reviewForm);
      console.log('Review response:', response);
      
      alert('Review added successfully!');
      setReviewForm({ rating: 5, comment: '' });
      fetchReviews();
      fetchUserReview();
    } catch (err) {
      console.error('Error adding review:', err);
      const errorMessage = err.response?.data?.message || err.message || 'Please try again';
      alert('Error adding review: ' + errorMessage);
    } finally {
      setIsAddingReview(false);
    }
  };

  const handleUpdateReview = async (e) => {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('token');
      if (!token || !userReview) {
        alert('Please login to update a review');
        return;
      }
      
      const response = await reviewAPI.updateReview(userReview.review_id, reviewForm);
      
      alert('Review updated successfully!');
      fetchReviews();
      fetchUserReview();
    } catch (err) {
      console.error('Error updating review:', err);
      const errorMessage = err.response?.data?.message || err.message || 'Please try again';
      alert('Error updating review: ' + errorMessage);
    }
  };

  const handleDeleteReview = async () => {
    if (!userReview) return;
    
    if (!window.confirm('Are you sure you want to delete your review?')) return;
    
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('Please login to delete a review');
        return;
      }
      
      await reviewAPI.deleteReview(userReview.review_id);
      
      alert('Review deleted successfully!');
      setUserReview(null);
      setReviewForm({ rating: 5, comment: '' });
      fetchReviews();
    } catch (err) {
      console.error('Error deleting review:', err);
      const errorMessage = err.response?.data?.message || err.message || 'Please try again';
      alert('Error deleting review: ' + errorMessage);
    }
  };

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const formatDuration = (minutes) => {
    if (!minutes) return 'N/A';
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    return `${hours}h ${mins}m`;
  };

  // Generate backdrop image URL
  const getBackdropUrl = () => {
    if (movieDetails.poster_url && movieDetails.poster_url.startsWith('http')) {
      // For TMDB images, we can create a backdrop version
      if (movieDetails.poster_url.includes('image.tmdb.org')) {
        return movieDetails.poster_url.replace('w500', 'w1280');
      }
      return movieDetails.poster_url;
    }
    return 'https://placehold.co/1280x300/2D3748/FFFFFF?text=Movie+Backdrop';
  };

  // Generate placeholder image with the movie title
  const generatePlaceholderImage = (title) => {
    const firstLetter = title ? title.charAt(0).toUpperCase() : 'M';
    return `https://placehold.co/300x450/2D3748/FFFFFF?text=${encodeURIComponent(firstLetter)}`;
  };

  // Determine the poster URL to use
  const getPosterUrl = (posterUrl, title) => {
    if (posterUrl && posterUrl.trim() !== '') {
      return posterUrl.startsWith('http') ? posterUrl : `http://localhost:5000${posterUrl}`;
    }
    return generatePlaceholderImage(title);
  };

  // Extract YouTube video ID from URL
  const getYouTubeVideoId = (url) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  if (loading) {
    return (
      <div className="modal-overlay" onClick={onClose}>
        <div className="movie-details-modal" onClick={e => e.stopPropagation()}>
          <div className="modal-header">
            <h2>Loading Movie Details...</h2>
            <button className="close-btn" onClick={onClose}>×</button>
          </div>
          <div className="modal-body">
            <div className="loading-spinner"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="movie-details-modal" onClick={e => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{movieDetails.title}</h2>
          <button className="close-btn" onClick={onClose}>×</button>
        </div>
        
        <div className="modal-body">
          {error && (
            <div className="error-message">
              <p>{error}</p>
            </div>
          )}
          
          {/* TMDB-like backdrop image */}
          <div 
            className="movie-backdrop"
            style={{ backgroundImage: `url(${getBackdropUrl()})` }}
          ></div>
          
          {/* TMDB-like tabs */}
          <div className="movie-tabs">
            <button 
              className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              Overview
            </button>
            {(movieDetails.actors && movieDetails.actors.length > 0) && (
              <button 
                className={`tab-btn ${activeTab === 'cast' ? 'active' : ''}`}
                onClick={() => setActiveTab('cast')}
              >
                Cast
              </button>
            )}
            {(movieDetails.directors && movieDetails.directors.length > 0) && (
              <button 
                className={`tab-btn ${activeTab === 'crew' ? 'active' : ''}`}
                onClick={() => setActiveTab('crew')}
              >
                Crew
              </button>
            )}
            {movieDetails.trailer_url && (
              <button 
                className={`tab-btn ${activeTab === 'media' ? 'active' : ''}`}
                onClick={() => setActiveTab('media')}
              >
                Media
              </button>
            )}
            <button 
              className={`tab-btn ${activeTab === 'reviews' ? 'active' : ''}`}
              onClick={() => setActiveTab('reviews')}
            >
              Reviews ({reviews.length})
            </button>
            {relatedMovies.length > 0 && (
              <button 
                className={`tab-btn ${activeTab === 'related' ? 'active' : ''}`}
                onClick={() => setActiveTab('related')}
              >
                Related Movies
              </button>
            )}
          </div>
          
          <div className="movie-content">
            <div className="movie-poster-section">
              <img 
                src={getPosterUrl(movieDetails.poster_url, movieDetails.title)} 
                alt={movieDetails.title}
                onError={(e) => {
                  e.target.src = generatePlaceholderImage(movieDetails.title);
                }}
              />
              <div className="movie-rating-display">
                <span className="rating-badge">
                  ⭐ {movieDetails.rating || 'N/A'}
                </span>
              </div>
            </div>
            
            <div className="movie-info-section">
              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <>
                  <div className="movie-meta">
                    <div className="meta-item">
                      <span className="meta-label">Release Date:</span>
                      <span className="meta-value">{formatDate(movieDetails.release_date)}</span>
                    </div>
                    <div className="meta-item">
                      <span className="meta-label">Duration:</span>
                      <span className="meta-value">{formatDuration(movieDetails.duration_minutes)}</span>
                    </div>
                    {movieDetails.genres && movieDetails.genres.length > 0 && (
                      <div className="meta-item">
                        <span className="meta-label">Genres:</span>
                        <span className="meta-value">
                          {movieDetails.genres.join(', ')}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  <div className="movie-description">
                    <h3>Overview</h3>
                    <p>{movieDetails.description || 'No description available.'}</p>
                  </div>
                </>
              )}
              
              {/* Cast Tab */}
              {activeTab === 'cast' && movieDetails.actors && movieDetails.actors.length > 0 && (
                <div className="movie-cast-section">
                  <h3>Cast</h3>
                  <div className="cast-list">
                    {movieDetails.actors.map((actor, index) => (
                      <div key={index} className="cast-member">
                        <div className="actor-placeholder">
                          <span className="actor-initial">{actor.charAt(0)}</span>
                        </div>
                        <div className="actor-info">
                          <span className="actor-name">{actor}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Crew Tab */}
              {activeTab === 'crew' && movieDetails.directors && movieDetails.directors.length > 0 && (
                <div className="movie-directors-section">
                  <h3>Crew</h3>
                  <div className="directors-list">
                    {movieDetails.directors.map((director, index) => (
                      <div key={index} className="director">
                        <div className="director-placeholder">
                          <span className="director-initial">{director.charAt(0)}</span>
                        </div>
                        <div className="director-info">
                          <span className="director-name">{director}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Media Tab - Trailers and additional media */}
              {activeTab === 'media' && movieDetails.trailer_url && (
                <div className="movie-media-section">
                  <h3>Trailers & Media</h3>
                  <div className="trailer-container">
                    {movieDetails.trailer_url && (
                      <div className="trailer-player">
                        <h4>Official Trailer</h4>
                        <div className="trailer-wrapper">
                          <iframe
                            src={`https://www.youtube.com/embed/${getYouTubeVideoId(movieDetails.trailer_url)}?rel=0`}
                            title={`${movieDetails.title} Trailer`}
                            frameBorder="0"
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                            allowFullScreen
                            className="trailer-iframe"
                          ></iframe>
                        </div>
                        <a 
                          href={movieDetails.trailer_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="trailer-link"
                        >
                          Watch on YouTube
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {/* Reviews Tab */}
              {activeTab === 'reviews' && (
                <div className="movie-reviews-section">
                  <h3>User Reviews</h3>
                  
                  {/* Add/Edit Review Form */}
                  <div className="review-form-section">
                    <h4>{userReview ? 'Edit Your Review' : 'Add Your Review'}</h4>
                    <form onSubmit={userReview ? handleUpdateReview : handleAddReview}>
                      <div className="rating-input">
                        <label>Rating: {reviewForm.rating}/10</label>
                        <input
                          type="range"
                          min="1"
                          max="10"
                          value={reviewForm.rating}
                          onChange={(e) => setReviewForm({...reviewForm, rating: parseInt(e.target.value)})}
                          className="rating-slider"
                        />
                      </div>
                      <div className="comment-input">
                        <label>Comment:</label>
                        <textarea
                          value={reviewForm.comment}
                          onChange={(e) => setReviewForm({...reviewForm, comment: e.target.value})}
                          placeholder="Share your thoughts about this movie..."
                          rows="4"
                          required
                        />
                      </div>
                      <div className="review-actions">
                        <button type="submit" className="submit-review-btn" disabled={isAddingReview}>
                          {isAddingReview ? 'Submitting...' : (userReview ? 'Update Review' : 'Submit Review')}
                        </button>
                        {userReview && (
                          <button type="button" onClick={handleDeleteReview} className="delete-review-btn">
                            Delete Review
                          </button>
                        )}
                      </div>
                    </form>
                  </div>
                  
                  {/* All Reviews */}
                  <div className="reviews-list">
                    <h4>Community Reviews ({reviews.length})</h4>
                    {reviews.length === 0 ? (
                      <p className="no-reviews">No reviews yet. Be the first to review this movie!</p>
                    ) : (
                      <div className="reviews-container">
                        {reviews.map((review) => (
                          <div key={review.review_id} className="review-card">
                            <div className="review-header">
                              <div className="reviewer-info">
                                <span className="reviewer-name">{review.username}</span>
                                <span className="review-date">
                                  {new Date(review.created_at).toLocaleDateString()}
                                </span>
                              </div>
                              <div className="review-rating">
                                <span className="rating-stars">
                                  {'★'.repeat(review.rating) + '☆'.repeat(10 - review.rating)}
                                </span>
                                <span className="rating-number">{review.rating}/10</span>
                              </div>
                            </div>
                            <div className="review-content">
                              <p>{review.comment}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              {/* Related Movies Tab */}
              {activeTab === 'related' && relatedMovies.length > 0 && (
                <div className="movie-related-section">
                  <h3>Related Movies</h3>
                  <div className="movies-grid">
                    {relatedMovies.map((relatedMovie) => (
                      <div 
                        key={relatedMovie.movie_id} 
                        className="movie-card"
                        onClick={(e) => {
                          e.stopPropagation();
                          // Refresh modal with new movie details
                          setMovieDetails(relatedMovie);
                          fetchRelatedMovies();
                          fetchReviews();
                          fetchUserReview();
                        }}
                      >
                        <div className="movie-poster">
                          <img 
                            src={getPosterUrl(relatedMovie.poster_url, relatedMovie.title)}
                            alt={relatedMovie.title}
                            onError={(e) => {
                              e.target.src = generatePlaceholderImage(relatedMovie.title);
                            }}
                            loading="lazy"
                          />
                          <div className="movie-overlay">
                            <div className="movie-rating">
                              ⭐ {relatedMovie.rating || 'N/A'}
                            </div>
                          </div>
                        </div>
                        
                        <div className="movie-info">
                          <h3 className="movie-title">{relatedMovie.title}</h3>
                          <div className="movie-details">
                            <div className="detail">
                              <span className="label">Released:</span>
                              <span className="value">{formatDate(relatedMovie.release_date)}</span>
                            </div>
                            {relatedMovie.genres && relatedMovie.genres.length > 0 && (
                              <div className="detail">
                                <span className="label">Genres:</span>
                                <span className="value">
                                  {relatedMovie.genres.slice(0, 2).join(', ')}
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieDetailsModal;