import React, { useState, useEffect } from 'react';
import axios from 'axios';
import toast, { Toaster } from 'react-hot-toast';
import MovieCard from './components/MovieCard';
import LoadingSkeleton from './components/LoadingSkeleton';
import './App.css';

// Function to detect the correct API base URL
const getApiBaseUrl = () => {
  // Check if we're in a browser environment
  if (typeof window !== 'undefined' && window.location) {
    // If we're on localhost, use localhost backend
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
      return import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
    }
    // If we're on mobile or another device, use the same hostname as the frontend
    return `http://${window.location.hostname}:5000/api`;
  }
  // Default fallback
  return import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
};

// Configure axios with the correct base URL
const API_BASE_URL = getApiBaseUrl();
axios.defaults.baseURL = API_BASE_URL;

// Log the API URL being used for debugging
console.log('Using API Base URL:', API_BASE_URL);

// Add Authorization header for all requests if token exists
axios.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor to handle token expiration
axios.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // If error is 401 and we haven't retried yet
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        // Try to refresh the token
        const refreshToken = localStorage.getItem('token');
        if (refreshToken) {
          const response = await axios.post('/auth/refresh', {}, {
            headers: {
              'Authorization': `Bearer ${refreshToken}`
            }
          });
          
          // Save new token
          const { token } = response.data.data;
          localStorage.setItem('token', token);
          
          // Retry original request with new token
          originalRequest.headers['Authorization'] = `Bearer ${token}`;
          return axios(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, clear tokens and show login
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.dispatchEvent(new CustomEvent('auth-expired'));
      }
    }
    
    return Promise.reject(error);
  }
);

const App = () => {
  const [movies, setMovies] = useState([]);
  const [filteredMovies, setFilteredMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [user, setUser] = useState(null);
  const [activeTab, setActiveTab] = useState('browse');
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState(''); // Remove default sorting
  const [sortOrder, setSortOrder] = useState(''); // Remove default sorting
  
  // Collections state
  const [collections, setCollections] = useState([]);
  const [selectedCollection, setSelectedCollection] = useState(null);
  const [showCollectionModal, setShowCollectionModal] = useState(false);
  const [collectionForm, setCollectionForm] = useState({
    name: '',
    description: '',
    is_public: false
  });
  
  // Statistics state
  const [stats, setStats] = useState(null);
  const [userStats, setUserStats] = useState(null);
  const [recentActivity, setRecentActivity] = useState(null);
  
  // Advanced search filters
  const [filters, setFilters] = useState({
    year: '',
    minRating: '',
    genre: 'all'
  });

  // Auth form states
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [registerData, setRegisterData] = useState({
    username: '', email: '', password: '', first_name: '', last_name: ''
  });

  // Movie form state
  const [movieForm, setMovieForm] = useState({
    title: '', 
    description: '', 
    release_date: '', 
    duration_minutes: '', 
    rating: '', 
    poster_url: '',
    auto_fetch: false
  });
  
  // Auth mode state
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('login');

  // Selected genre state
  const [selectedGenre, setSelectedGenre] = useState('all');

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalCount, setTotalCount] = useState(0);
  const [itemsPerPage, setItemsPerPage] = useState(50); // Increased default to 50

  // Get unique genres for filter
  const getUniqueGenres = () => {
    const allGenres = movies.flatMap(movie => movie.genres || []);
    return [...new Set(allGenres)].filter(genre => genre);
  };

  useEffect(() => {
    console.log('=== App Component Mounted ===');
    // Hide loading screen
    const loading = document.getElementById("loading");
    if (loading) {
      loading.style.display = "none";
    }
    
    fetchMovies();
    checkAuth();
    
    // Add event listener for auth expiration
    const handleAuthExpired = () => {
      setUser(null);
      toast.error('🔐 Session expired. Please login again.');
    };
    
    window.addEventListener('auth-expired', handleAuthExpired);
    
    // Cleanup listener on unmount
    return () => {
      window.removeEventListener('auth-expired', handleAuthExpired);
    };
  }, []);

  useEffect(() => {
    if (user) {
      fetchCollections();
    }
  }, [user]);

  useEffect(() => {
    if (activeTab === 'dashboard') {
      fetchStats();
      if (user) {
        fetchUserStats();
      }
      fetchRecentActivity();
    }
  }, [activeTab, user]);

  useEffect(() => {
    // Fetch movies when sorting changes
    fetchMovies();
  }, [sortBy, sortOrder, currentPage]);

  useEffect(() => {
    // Fetch movies when filters or search term changes
    // Reset to first page when filters change
    setCurrentPage(1);
    fetchMovies();
  }, [filters, searchTerm]);

  const checkAuth = () => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      setUser(JSON.parse(userData));
    }
  };

  const fetchMovies = async () => {
    try {
      setLoading(true);
      setError('');
      
      console.log('=== DEBUG: fetchMovies called ===');
      console.log('Current sortBy:', sortBy);
      console.log('Current sortOrder:', sortOrder);
      console.log('Current searchTerm:', searchTerm);
      console.log('Current filters:', filters);
      console.log('Current page:', currentPage);
      
      // Build query parameters for advanced search
      const queryParams = new URLSearchParams();
      queryParams.append('page', currentPage);
      queryParams.append('limit', itemsPerPage); // Use itemsPerPage instead of fixed 20
      if (searchTerm) queryParams.append('search', searchTerm);
      if (filters.genre && filters.genre !== 'all') queryParams.append('genre', filters.genre);
      if (filters.year) queryParams.append('year', filters.year);
      if (filters.minRating) queryParams.append('rating', filters.minRating);
      
      // Handle sorting - only send if both sortBy and sortOrder are set
      if (sortBy && sortOrder) {
        const sortParam = `${sortBy}-${sortOrder}`;
        queryParams.append('sortBy', sortParam);
        console.log('Adding sort param:', sortParam);
      } else {
        console.log('No sorting parameters to add');
      }
      
      console.log('Fetching movies with params:', { 
        sortBy, 
        sortOrder,
        searchTerm,
        filters,
        page: currentPage,
        limit: itemsPerPage,
        queryString: queryParams.toString()
      });
      
      const response = await axios.get(`/movies?${queryParams.toString()}`);
      console.log('Received movies:', response.data.data.length);
      setMovies(response.data.data || []);
      
      // Update pagination info
      if (response.data.pagination) {
        setTotalPages(response.data.pagination.totalPages || 1);
        setTotalCount(response.data.pagination.totalCount || 0);
        console.log('Pagination updated:', {
          totalPages: response.data.pagination.totalPages,
          totalCount: response.data.pagination.totalCount,
          itemsPerPage: itemsPerPage
        });
      }
    } catch (err) {
      console.error('Error fetching movies:', err);
      setError('Failed to connect to backend. Make sure it\'s running on http://localhost:5000 and CORS is configured correctly');
      toast.error('🚫 Failed to connect to backend. Make sure it\'s running on http://localhost:5000 and CORS is configured correctly');
    } finally {
      setLoading(false);
    }
  };

  const fetchCollections = async () => {
    if (!user) return;
    
    try {
      const response = await axios.get('/collections');
      setCollections(response.data.data || []);
    } catch (err) {
      console.error('Error fetching collections:', err);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await axios.get('/stats');
      setStats(response.data.data);
    } catch (err) {
      console.error('Error fetching stats:', err);
    }
  };

  const fetchUserStats = async () => {
    if (!user) return;
    
    try {
      const response = await axios.get('/stats/user');
      setUserStats(response.data.data);
    } catch (err) {
      console.error('Error fetching user stats:', err);
    }
  };

  const fetchRecentActivity = async () => {
    try {
      const response = await axios.get('/stats/activity');
      setRecentActivity(response.data.data);
    } catch (err) {
      console.error('Error fetching recent activity:', err);
    }
  };

  const filterAndSortMovies = () => {
    console.log('=== DEBUG: filterAndSortMovies called ===');
    // Filtering and sorting is now handled by the backend
    // Just trigger a new fetch when filters or sorting changes
    fetchMovies();
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/auth/login', loginData);
      const { user, token } = response.data.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      setUser(user);
      toast.success('🎉 Login successful!');
      setShowAuth(false);
      setLoginData({ email: '', password: '' });
    } catch (err) {
      toast.error('❌ Login failed: ' + (err.response?.data?.message || 'Invalid credentials'));
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/auth/register', registerData);
      const { user, token } = response.data.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('user', JSON.stringify(user));
      setUser(user);
      toast.success('🎉 Registration successful!');
      setShowAuth(false);
      setRegisterData({ username: '', email: '', password: '', first_name: '', last_name: '' });
    } catch (err) {
      toast.error('❌ Registration failed: ' + (err.response?.data?.message || 'Please try again'));
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setCollections([]);
    setUserStats(null);
    toast.success('👋 Logged out successfully!');
  };

  const handleAddMovie = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      if (!token) {
        toast.error('🔐 Please login to add movies');
        setShowAuth(true);
        return;
      }

      // If auto-fetch is enabled, we don't need to validate required fields
      if (movieForm.auto_fetch) {
        // Only title is required for auto-fetch
        if (!movieForm.title.trim()) {
          toast.error('🎬 Please enter a movie title for auto-fetch');
          return;
        }
      } else {
        // For manual entry, validate required fields
        if (!movieForm.title.trim()) {
          toast.error('🎬 Please enter a movie title');
          return;
        }
        if (!movieForm.release_date) {
          toast.error('📅 Please enter a release date');
          return;
        }
        if (!movieForm.duration_minutes) {
          toast.error('⏱️ Please enter a duration');
          return;
        }
        if (!movieForm.description.trim()) {
          toast.error('📝 Please enter a description');
          return;
        }
      }

      // Prepare movie data - for auto-fetch, send null for empty fields
      const movieData = {
        title: movieForm.title,
        auto_fetch: movieForm.auto_fetch || false
      };

      // Only include other fields if they have values or if auto-fetch is disabled
      if (!movieForm.auto_fetch) {
        movieData.description = movieForm.description;
        movieData.release_date = movieForm.release_date;
        movieData.duration_minutes = movieForm.duration_minutes ? parseInt(movieForm.duration_minutes) : null;
        movieData.rating = movieForm.rating ? parseFloat(movieForm.rating) : null;
        movieData.poster_url = movieForm.poster_url;
      } else {
        // For auto-fetch, only include fields that have actual values
        if (movieForm.description) movieData.description = movieForm.description;
        if (movieForm.release_date) movieData.release_date = movieForm.release_date;
        if (movieForm.duration_minutes) movieData.duration_minutes = parseInt(movieForm.duration_minutes);
        if (movieForm.rating) movieData.rating = parseFloat(movieForm.rating);
        if (movieForm.poster_url) movieData.poster_url = movieForm.poster_url;
      }

      // Explicitly set the authorization header
      const config = {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };

      await axios.post('/movies', movieData, config);
      toast.success('🎬 Movie added successfully!');
      setMovieForm({ 
        title: '', 
        description: '', 
        release_date: '', 
        duration_minutes: '', 
        rating: '', 
        poster_url: '',
        auto_fetch: false
      });
      fetchMovies();
      setActiveTab('browse');
    } catch (err) {
      console.error('Movie creation error:', err);
      const errorMessage = err.response?.data?.message || err.message || 'Unknown error occurred';
      
      // Handle token expiration specifically
      if (err.response?.status === 401) {
        // Clear expired token
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        setUser(null);
        toast.error('🔐 Session expired. Please login again to add movies');
        setShowAuth(true);
      } else {
        toast.error(`❌ Failed to add movie: ${errorMessage}`);
      }
      
      console.log('Error details:', {
        status: err.response?.status,
        statusText: err.response?.statusText,
        data: err.response?.data,
        message: err.message
      });
    }
  };

  const handleDeleteMovie = async (movieId) => {
    if (!window.confirm('🗑️ Are you sure you want to delete this movie?')) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`/movies/${movieId}`);
      toast.success('✅ Movie deleted successfully!');
      fetchMovies();
    } catch (err) {
      toast.error('❌ Failed to delete movie: ' + (err.response?.data?.message || 'Check console'));
    }
  };

  const clearSearch = () => {
    setSearchTerm('');
    setSelectedGenre('all');
    setFilters({
      year: '',
      minRating: '',
      genre: 'all'
    });
  };

  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({
      ...prev,
      [filterName]: value
    }));
  };

  const handleSortChange = (e) => {
    console.log('=== DEBUG: handleSortChange called ===');
    console.log('Selected value:', e.target.value);
    
    // If empty value (No Sorting), clear both sortBy and sortOrder
    if (!e.target.value) {
      setSortBy('');
      setSortOrder('');
    } else {
      const [field, order] = e.target.value.split('-');
      console.log('Parsed field:', field);
      console.log('Parsed order:', order);
      
      setSortBy(field);
      setSortOrder(order);
      
      console.log('Updated state - sortBy:', field);
      console.log('Updated state - sortOrder:', order);
    }
  };

  // Collection functions
  const handleCreateCollection = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('/collections', collectionForm);
      toast.success('✅ Collection created successfully!');
      setCollectionForm({ name: '', description: '', is_public: false });
      setShowCollectionModal(false);
      fetchCollections();
    } catch (err) {
      toast.error('❌ Failed to create collection: ' + (err.response?.data?.message || 'Please try again'));
    }
  };

  const handleDeleteCollection = async (collectionId) => {
    if (!window.confirm('🗑️ Are you sure you want to delete this collection?')) return;
    
    try {
      await axios.delete(`/collections/${collectionId}`);
      toast.success('✅ Collection deleted successfully!');
      fetchCollections();
      if (selectedCollection && selectedCollection.collection_id === collectionId) {
        setSelectedCollection(null);
        setActiveTab('collections');
      }
    } catch (err) {
      toast.error('❌ Failed to delete collection: ' + (err.response?.data?.message || 'Check console'));
    }
  };

  const handleAddMovieToCollection = async (collectionId, movieId) => {
    try {
      await axios.post(`/collections/${collectionId}/movies`, { movieId });
      toast.success('✅ Movie added to collection!');
    } catch (err) {
      toast.error('❌ Failed to add movie to collection: ' + (err.response?.data?.message || 'Please try again'));
    }
  };

  const handleRemoveMovieFromCollection = async (collectionId, movieId) => {
    try {
      await axios.delete(`/collections/${collectionId}/movies/${movieId}`);
      toast.success('✅ Movie removed from collection!');
      // Refresh collection if it's currently selected
      if (selectedCollection && selectedCollection.collection_id === collectionId) {
        const response = await axios.get(`/collections/${collectionId}`);
        setSelectedCollection(response.data.data);
      }
    } catch (err) {
      toast.error('❌ Failed to remove movie from collection: ' + (err.response?.data?.message || 'Please try again'));
    }
  };

  // Generate placeholder image with the movie title
  const generatePlaceholderImage = (title) => {
    const firstLetter = title ? title.charAt(0).toUpperCase() : 'M';
    return `https://placehold.co/300x450/2D3748/FFFFFF?text=${encodeURIComponent(firstLetter)}`;
  };

  // Determine the poster URL to use
  const getPosterUrl = (posterUrl, title) => {
    if (posterUrl && posterUrl.trim() !== '') {
      return posterUrl.startsWith('http') ? posterUrl : `http://localhost:5000${posterUrl}`;
    }
    return generatePlaceholderImage(title);
  };

  // Add pagination controls component
  const renderPaginationControls = () => {
    // Array of page size options
    const pageSizeOptions = [10, 20, 50, 100]; // Added 100 as an option
    
    return (
      <div className="pagination-container">
        <div className="pagination-controls">
          <button 
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className="pagination-btn"
          >
            ← Previous
          </button>
          
          <span className="pagination-info">
            Page {currentPage} of {totalPages || 1} ({totalCount || 0} total movies)
          </span>
          
          <button 
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages || 1))}
            disabled={currentPage >= (totalPages || 1)}
            className="pagination-btn"
          >
            Next →
          </button>
          
          <div className="page-size-selector">
            <label htmlFor="page-size">Items per page:</label>
            <select 
              id="page-size"
              value={itemsPerPage}
              onChange={(e) => {
                setItemsPerPage(Number(e.target.value));
                setCurrentPage(1); // Reset to first page when changing page size
              }}
              className="sort-select"
            >
              {pageSizeOptions.map(size => (
                <option key={size} value={size}>{size}</option>
              ))}
            </select>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="app">
      {/* Toast Notifications */}
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#1a1a1a',
            color: '#fff',
            border: '1px solid #444',
          },
          success: {
            iconTheme: {
              primary: '#48bb78',
              secondary: '#fff',
            },
          },
          error: {
            iconTheme: {
              primary: '#e53e3e',
              secondary: '#fff',
            },
          },
        }}
      />
      
      {/* Header */}
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">🎬</div>
            <div className="logo-text">
              <h1>CineMaster Pro</h1>
              <p>Your Ultimate Movie Database</p>
            </div>
          </div>
          
          <nav className="nav">
            <button 
              className={`nav-btn ${activeTab === 'browse' ? 'active' : ''}`}
              onClick={() => setActiveTab('browse')}
            >
              🎭 Browse Movies
            </button>
            
            {user && (
              <>
                <button 
                  className={`nav-btn ${activeTab === 'add' ? 'active' : ''}`}
                  onClick={() => setActiveTab('add')}
                >
                  ➕ Add Movie
                </button>
                <button 
                  className={`nav-btn ${activeTab === 'collections' ? 'active' : ''}`}
                  onClick={() => setActiveTab('collections')}
                >
                  📚 My Collections
                </button>
                <button 
                  className={`nav-btn ${activeTab === 'dashboard' ? 'active' : ''}`}
                  onClick={() => setActiveTab('dashboard')}
                >
                  📊 Dashboard
                </button>
              </>
            )}
            
            {/* TMDB-like search in navigation */}
            <div className="nav-search">
              <span className="nav-search-icon">🔍</span>
              <input
                type="text"
                placeholder="Search movies..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
              />
            </div>
          </nav>

          <div className="user-actions">
            {user ? (
              <div className="user-info">
                <span>👤 {user.username}</span>
                <button onClick={handleLogout} className="logout-btn">Logout</button>
              </div>
            ) : (
              <button onClick={() => setShowAuth(true)} className="login-btn">🔑 Login</button>
            )}
          </div>
        </div>
      </header>

      {/* Auth Modal */}
      {showAuth && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h2>{authMode === 'login' ? 'Welcome Back' : 'Join CineMaster'}</h2>
              <button className="close-btn" onClick={() => setShowAuth(false)}>×</button>
            </div>

            <div className="auth-tabs">
              <button 
                className={`tab-btn ${authMode === 'login' ? 'active' : ''}`}
                onClick={() => setAuthMode('login')}
              >
                Login
              </button>
              <button 
                className={`tab-btn ${authMode === 'register' ? 'active' : ''}`}
                onClick={() => setAuthMode('register')}
              >
                Register
              </button>
            </div>

            {authMode === 'login' ? (
              <form onSubmit={handleLogin} className="auth-form">
                <input
                  type="email"
                  placeholder="📧 Email"
                  value={loginData.email}
                  onChange={(e) => setLoginData({...loginData, email: e.target.value})}
                  required
                />
                <input
                  type="password"
                  placeholder="🔒 Password"
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  required
                />
                <button type="submit" className="auth-submit-btn">Login</button>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="auth-form">
                <input
                  type="text"
                  placeholder="👤 Username"
                  value={registerData.username}
                  onChange={(e) => setRegisterData({...registerData, username: e.target.value})}
                  required
                />
                <input
                  type="email"
                  placeholder="📧 Email"
                  value={registerData.email}
                  onChange={(e) => setRegisterData({...registerData, email: e.target.value})}
                  required
                />
                <input
                  type="password"
                  placeholder="🔒 Password"
                  value={registerData.password}
                  onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
                  required
                />
                <div className="name-fields">
                  <input
                    type="text"
                    placeholder="First Name"
                    value={registerData.first_name}
                    onChange={(e) => setRegisterData({...registerData, first_name: e.target.value})}
                  />
                  <input
                    type="text"
                    placeholder="Last Name"
                    value={registerData.last_name}
                    onChange={(e) => setRegisterData({...registerData, last_name: e.target.value})}
                  />
                </div>
                <button type="submit" className="auth-submit-btn">Create Account</button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Collection Modal */}
      {showCollectionModal && (
        <div className="modal-overlay" onClick={() => setShowCollectionModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Create New Collection</h2>
              <button className="close-btn" onClick={() => setShowCollectionModal(false)}>×</button>
            </div>
            <form onSubmit={handleCreateCollection} className="auth-form">
              <input
                type="text"
                placeholder="Collection Name"
                value={collectionForm.name}
                onChange={(e) => setCollectionForm({...collectionForm, name: e.target.value})}
                required
              />
              <textarea
                placeholder="Description (optional)"
                value={collectionForm.description}
                onChange={(e) => setCollectionForm({...collectionForm, description: e.target.value})}
                rows="3"
              />
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={collectionForm.is_public}
                  onChange={(e) => setCollectionForm({...collectionForm, is_public: e.target.checked})}
                />
                Make this collection public
              </label>
              <button type="submit" className="auth-submit-btn">Create Collection</button>
            </form>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="main-content">
        {activeTab === 'browse' && (
          <div className="browse-section">
            {/* Search and Controls */}
            <div className="controls">
              <div className="search-box">
                <input
                  type="text"
                  placeholder="🔍 Search movies by title or description..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="search-input"
                />
                {searchTerm && (
                  <button onClick={clearSearch} className="clear-search" title="Clear search">
                    ✕
                  </button>
                )}
              </div>

              <div className="filters">
                {/* Advanced Filters */}
                <select 
                  value={filters.genre} 
                  onChange={(e) => handleFilterChange('genre', e.target.value)} 
                  className="sort-select"
                >
                  <option value="all">All Genres</option>
                  {getUniqueGenres().map(genre => (
                    <option key={genre} value={genre}>{genre}</option>
                  ))}
                </select>
                
                <input
                  type="number"
                  placeholder="Year"
                  value={filters.year}
                  onChange={(e) => handleFilterChange('year', e.target.value)}
                  className="sort-select"
                  min="1900"
                  max={new Date().getFullYear()}
                />
                
                <select 
                  value={filters.minRating} 
                  onChange={(e) => handleFilterChange('minRating', e.target.value)} 
                  className="sort-select"
                >
                  <option value="">Any Rating</option>
                  <option value="9">9+ Stars</option>
                  <option value="8">8+ Stars</option>
                  <option value="7">7+ Stars</option>
                  <option value="6">6+ Stars</option>
                  <option value="5">5+ Stars</option>
                </select>
                
                <select 
                  value={sortBy && sortOrder ? `${sortBy}-${sortOrder}` : ''}
                  onChange={handleSortChange}
                  className="sort-select"
                >
                  <option value="">No Sorting</option>
                  <option value="title-asc">Title A-Z</option>
                  <option value="title-desc">Title Z-A</option>
                  <option value="rating-desc">Rating (High to Low)</option>
                  <option value="rating-asc">Rating (Low to High)</option>
                  <option value="genres-asc">Genre (A-Z)</option>
                  <option value="genres-desc">Genre (Z-A)</option>
                  <option value="release_date-desc">Release Date (Newest)</option>
                  <option value="release_date-asc">Release Date (Oldest)</option>
                  <option value="duration_minutes-desc">Duration (Longest)</option>
                  <option value="duration_minutes-asc">Duration (Shortest)</option>
                </select>
                
                <button onClick={fetchMovies} className="refresh-btn">🔄 Refresh</button>
              </div>
            </div>

            {/* Stats */}
            <div className="stats">
              <div className="stat-card">
                <span className="stat-number">{totalCount || movies.length}</span>
                <span className="stat-label">Movies Found</span>
              </div>
            </div>

            {/* Content */}
            {loading ? (
              <LoadingSkeleton count={6} />
            ) : error ? (
              <div className="error-state">
                <h3>😞 Connection Issue</h3>
                <p>{error}</p>
                <button onClick={fetchMovies} className="retry-btn">🔄 Retry Connection</button>
              </div>
            ) : movies.length === 0 ? (
              <div className="empty-state">
                <h3>🎬 No movies found</h3>
                <p>
                  {searchTerm || filters.genre !== 'all' || filters.year || filters.minRating
                    ? 'No movies match your search criteria. Try different filters.'
                    : 'Get started by adding your first movie!'
                  }
                </p>
                {!searchTerm && !filters.year && !filters.minRating && filters.genre === 'all' && user && (
                  <button 
                    className="cta-btn"
                    onClick={() => setActiveTab('add')}
                  >
                    ➕ Add Your First Movie
                  </button>
                )}
                {(searchTerm || filters.genre !== 'all' || filters.year || filters.minRating) && (
                  <button className="cta-btn secondary" onClick={clearSearch}>
                    🔄 Clear Filters
                  </button>
                )}
              </div>
            ) : (
              <>
                <div className="movies-grid">
                  {/* Show all movies (pagination handled by backend) */}
                  {movies.map((movie) => (
                    <MovieCard
                      key={movie.movie_id}
                      movie={movie}
                      onDelete={handleDeleteMovie}
                      canDelete={!!user}
                      onAddToCollection={(collectionId) => handleAddMovieToCollection(collectionId, movie.movie_id)}
                      collections={collections}
                    />
                  ))}
                </div>
                
                {/* Pagination Controls */}
                {(() => {
                  const shouldShowPagination = totalPages > 1 || itemsPerPage < totalCount;
                  console.log('Pagination display check:', { totalPages, itemsPerPage, totalCount, shouldShowPagination });
                  return shouldShowPagination ? renderPaginationControls() : null;
                })()}
              </>
            )}
          </div>
        )}

        {activeTab === 'add' && (
          <div className="add-movie-section">
            <div className="form-container">
              <h2>🎬 Add New Movie</h2>
              
              {!user ? (
                <div className="auth-required">
                  <p>🔐 Please login to add movies</p>
                  <button onClick={() => setShowAuth(true)} className="auth-btn">
                    Login / Register
                  </button>
                </div>
              ) : (
                <form onSubmit={handleAddMovie} className="movie-form">
                  <div className="form-grid">
                    <div className="form-group">
                      <label>🎬 Movie Title *</label>
                      <input
                        type="text"
                        value={movieForm.title}
                        onChange={(e) => setMovieForm({...movieForm, title: e.target.value})}
                        placeholder="Enter movie title"
                        required
                      />
                    </div>

                    <div className="form-group">
                      <label>📅 Release Date {movieForm.auto_fetch ? '' : '*'}</label>
                      <input
                        type="date"
                        value={movieForm.release_date}
                        onChange={(e) => setMovieForm({...movieForm, release_date: e.target.value})}
                        required={!movieForm.auto_fetch}
                        disabled={movieForm.auto_fetch}
                      />
                    </div>

                    <div className="form-group">
                      <label>⏱️ Duration (minutes) {movieForm.auto_fetch ? '' : '*'}</label>
                      <input
                        type="number"
                        value={movieForm.duration_minutes}
                        onChange={(e) => setMovieForm({...movieForm, duration_minutes: e.target.value})}
                        placeholder="120"
                        min="1"
                        required={!movieForm.auto_fetch}
                        disabled={movieForm.auto_fetch}
                      />
                    </div>

                    <div className="form-group">
                      <label>⭐ Rating (0-10)</label>
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        max="10"
                        value={movieForm.rating}
                        onChange={(e) => setMovieForm({...movieForm, rating: e.target.value})}
                        placeholder="8.5"
                        disabled={movieForm.auto_fetch}
                      />
                    </div>

                    <div className="form-group full-width">
                      <label>🖼️ Poster URL</label>
                      <input
                        type="url"
                        value={movieForm.poster_url}
                        onChange={(e) => setMovieForm({...movieForm, poster_url: e.target.value})}
                        placeholder="https://example.com/poster.jpg"
                        disabled={movieForm.auto_fetch}
                      />
                    </div>

                    <div className="form-group full-width">
                      <label>
                        <input
                          type="checkbox"
                          checked={movieForm.auto_fetch || false}
                          onChange={(e) => setMovieForm({...movieForm, auto_fetch: e.target.checked})}
                        />
                        🔍 Auto-fetch movie information (poster, cast, directors)
                      </label>
                      <p className="help-text">
                        When enabled, the system will automatically fetch movie information 
                        including poster, cast, and director details based on the movie title.
                        Other fields will be automatically populated and disabled.
                      </p>
                    </div>

                    <div className="form-group full-width">
                      <label>📝 Description {movieForm.auto_fetch ? '' : '*'}</label>
                      <textarea
                        value={movieForm.description}
                        onChange={(e) => setMovieForm({...movieForm, description: e.target.value})}
                        placeholder="Enter movie description..."
                        rows="4"
                        required={!movieForm.auto_fetch}
                        disabled={movieForm.auto_fetch}
                      />
                    </div>
                  </div>

                  <div className="form-actions">
                    <button type="submit" className="submit-btn primary">
                      🎬 Add Movie
                    </button>
                    <button 
                      type="button" 
                      className="submit-btn secondary"
                      onClick={() => setActiveTab('browse')}
                    >
                      ← Back to Movies
                    </button>
                  </div>
                </form>
              )}

              {/* Live Preview - Show when title is entered or auto-fetch is enabled */}
              {(movieForm.title || movieForm.auto_fetch) && (
                <div className="preview-section">
                  <h3>Live Preview</h3>
                  <div className="preview-card">
                    <div className="preview-poster">
                      <img 
                        src={movieForm.poster_url || 'https://via.placeholder.com/200x300/2D3748/FFFFFF?text=Preview'} 
                        alt="Preview"
                        onError={(e) => {
                          e.target.src = 'https://via.placeholder.com/200x300/2D3748/FFFFFF?text=Preview';
                        }}
                      />
                    </div>
                    <div className="preview-info">
                      <h4>{movieForm.title || 'Movie Title'}</h4>
                      <p>{movieForm.description || 'Movie description will appear here...'}</p>
                      <div className="preview-details">
                        {movieForm.rating && <span>⭐ {movieForm.rating}</span>}
                        {movieForm.duration_minutes && <span>⏱️ {movieForm.duration_minutes} min</span>}
                        {movieForm.release_date && <span>📅 {new Date(movieForm.release_date).toLocaleDateString()}</span>}
                      </div>
                      {movieForm.auto_fetch && (
                        <div className="auto-fetch-indicator">
                          <span>🔍 Auto-fetch enabled - information will be retrieved automatically</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'collections' && (
          <div className="collections-section">
            <div className="section-header">
              <h2>📚 My Collections</h2>
              {user && (
                <button 
                  className="create-collection-btn"
                  onClick={() => setShowCollectionModal(true)}
                >
                  ➕ Create Collection
                </button>
              )}
            </div>
            
            {!user ? (
              <div className="auth-required">
                <p>🔐 Please login to view and manage your collections</p>
                <button onClick={() => setShowAuth(true)} className="auth-btn">
                  Login / Register
                </button>
              </div>
            ) : collections.length === 0 ? (
              <div className="empty-state">
                <h3>📚 No collections yet</h3>
                <p>Create your first collection to organize your favorite movies!</p>
                <button 
                  className="cta-btn"
                  onClick={() => setShowCollectionModal(true)}
                >
                  ➕ Create Your First Collection
                </button>
              </div>
            ) : (
              <div className="collections-grid">
                {collections.map((collection) => (
                  <div 
                    key={collection.collection_id} 
                    className="collection-card"
                    onClick={async () => {
                      try {
                        // Fetch the detailed collection data including movies
                        const response = await axios.get(`/collections/${collection.collection_id}`);
                        setSelectedCollection(response.data.data);
                        setActiveTab('collection-detail');
                      } catch (err) {
                        console.error('Error fetching collection details:', err);
                        toast.error('❌ Failed to load collection details: ' + (err.response?.data?.message || 'Please try again'));
                      }
                    }}
                  >
                    <div className="collection-info">
                      <h3>{collection.name}</h3>
                      <p>{collection.description || 'No description'}</p>
                      <div className="collection-meta">
                        <span>🎬 {collection.movie_count || 0} movies</span>
                        <span>{collection.is_public ? '🌍 Public' : '🔒 Private'}</span>
                      </div>
                    </div>
                    <div className="collection-actions">
                      <button 
                        className="delete-collection-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteCollection(collection.collection_id);
                        }}
                      >
                        🗑️ Delete
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'collection-detail' && selectedCollection && (
          <div className="collection-detail-section">
            <div className="section-header">
              <button 
                className="back-btn"
                onClick={() => setActiveTab('collections')}
              >
                ← Back to Collections
              </button>
              <h2>{selectedCollection.name}</h2>
              <div className="collection-detail-meta">
                <span>🎬 {selectedCollection.movies?.length || 0} movies</span>
                <span>{selectedCollection.is_public ? '🌍 Public' : '🔒 Private'}</span>
              </div>
            </div>
            
            {selectedCollection.description && (
              <div className="collection-description">
                <p>{selectedCollection.description}</p>
              </div>
            )}
            
            {selectedCollection.movies && selectedCollection.movies.length > 0 ? (
              <div className="movies-grid">
                {selectedCollection.movies.map((movie) => (
                  <MovieCard
                    key={movie.movie_id}
                    movie={movie}
                    onDelete={handleDeleteMovie}
                    canDelete={!!user}
                    onRemoveFromCollection={() => handleRemoveMovieFromCollection(selectedCollection.collection_id, movie.movie_id)}
                    showRemoveButton={true}
                  />
                ))}
              </div>
            ) : (
              <div className="empty-state">
                <h3>🎬 No movies in this collection</h3>
                <p>Add movies to your collection from the browse section!</p>
                <button 
                  className="cta-btn"
                  onClick={() => setActiveTab('browse')}
                >
                  🔍 Browse Movies
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'dashboard' && (
          <div className="dashboard-section">
            <div className="section-header">
              <h2>📊 Analytics Dashboard</h2>
            </div>
            
            {/* Overall Stats */}
            {stats ? (
              <div className="dashboard-stats">
                <div className="stats-grid">
                  <div className="stat-card large">
                    <span className="stat-number">{stats.totals.movies}</span>
                    <span className="stat-label">Total Movies</span>
                  </div>
                  <div className="stat-card large">
                    <span className="stat-number">{stats.totals.users}</span>
                    <span className="stat-label">Total Users</span>
                  </div>
                  <div className="stat-card large">
                    <span className="stat-number">{stats.totals.reviews}</span>
                    <span className="stat-label">Total Reviews</span>
                  </div>
                  <div className="stat-card large">
                    <span className="stat-number">{stats.totals.averageRating}</span>
                    <span className="stat-label">Avg. Rating</span>
                  </div>
                </div>
                
                <div className="dashboard-content">
                  {/* User Stats (if logged in) */}
                  {user && userStats && (
                    <div className="user-stats-section">
                      <h3>👤 Your Statistics</h3>
                      <div className="stats-grid">
                        <div className="stat-card">
                          <span className="stat-number">{userStats.user.moviesAdded}</span>
                          <span className="stat-label">Movies Added</span>
                        </div>
                        <div className="stat-card">
                          <span className="stat-number">{userStats.user.reviewsWritten}</span>
                          <span className="stat-label">Reviews Written</span>
                        </div>
                        <div className="stat-card">
                          <span className="stat-number">{userStats.user.collectionsCreated}</span>
                          <span className="stat-label">Collections</span>
                        </div>
                        <div className="stat-card">
                          <span className="stat-number">{userStats.user.averageRatingGiven}</span>
                          <span className="stat-label">Avg. Rating Given</span>
                        </div>
                      </div>
                      
                      {userStats.user.favoriteGenres.length > 0 && (
                        <div className="favorite-genres">
                          <h4>🎭 Your Favorite Genres</h4>
                          <div className="genres-list">
                            {userStats.user.favoriteGenres.map((genre, index) => (
                              <div key={index} className="genre-item">
                                <span className="genre-name">{genre.genre_name}</span>
                                <span className="genre-count">{genre.count} movies</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                  
                  {/* Top Rated Movies */}
                  <div className="top-movies-section">
                    <h3>⭐ Top Rated Movies</h3>
                    <div className="movies-grid small">
                      {stats.topRatedMovies.map((movie) => (
                        <div key={movie.movie_id} className="movie-card compact">
                          <div className="movie-poster">
                            <img 
                              src={getPosterUrl(movie.poster_url, movie.title)}
                              alt={movie.title}
                              onError={(e) => {
                                e.target.src = generatePlaceholderImage(movie.title);
                              }}
                            />
                          </div>
                          <div className="movie-info compact">
                            <h4 className="movie-title">{movie.title}</h4>
                            <div className="movie-rating compact">
                              ⭐ {movie.rating}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Most Reviewed Movies */}
                  <div className="top-movies-section">
                    <h3>💬 Most Reviewed Movies</h3>
                    <div className="movies-grid small">
                      {stats.mostReviewedMovies.map((movie) => (
                        <div key={movie.movie_id} className="movie-card compact">
                          <div className="movie-poster">
                            <img 
                              src={getPosterUrl(movie.poster_url, movie.title)}
                              alt={movie.title}
                              onError={(e) => {
                                e.target.src = generatePlaceholderImage(movie.title);
                              }}
                            />
                          </div>
                          <div className="movie-info compact">
                            <h4 className="movie-title">{movie.title}</h4>
                            <div className="review-stats">
                              <span>💬 {movie.review_count} reviews</span>
                              <span>⭐ {parseFloat(movie.avg_rating).toFixed(1)}</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Recent Activity */}
                  {recentActivity && (
                    <div className="recent-activity-section">
                      <h3>🔥 Recent Activity</h3>
                      <div className="activity-list">
                        {recentActivity.recentMovies.slice(0, 3).map((movie, index) => (
                          <div key={index} className="activity-item">
                            <div className="activity-icon">🎬</div>
                            <div className="activity-content">
                              <p><strong>{movie.added_by}</strong> added <strong>{movie.title}</strong></p>
                              <span className="activity-time">
                                {new Date(movie.created_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        ))}
                        
                        {recentActivity.recentReviews.slice(0, 3).map((review, index) => (
                          <div key={index} className="activity-item">
                            <div className="activity-icon">💬</div>
                            <div className="activity-content">
                              <p><strong>{review.reviewer}</strong> reviewed <strong>{review.movie_title}</strong></p>
                              <p className="review-preview">"{review.comment.substring(0, 50)}..."</p>
                              <span className="activity-time">
                                {new Date(review.created_at).toLocaleDateString()}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <div className="loading-state">
                <div className="spinner"></div>
                <p>Loading dashboard data...</p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="footer">
        <div className="footer-content">
          <p>🎬 CineMaster Pro - Ultimate Movie Database</p>
          <div className="footer-info">
            <span>📊 {movies.length} movies in database</span>
            <span>👤 {user ? `Welcome, ${user.username}` : 'Not logged in'}</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;