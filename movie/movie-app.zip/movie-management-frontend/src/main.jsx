import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App.jsx";
import "./index.css";

// Ensure loading screen is hidden when app loads
const hideLoadingScreen = () => {
  const loading = document.getElementById("loading");
  if (loading) {
    loading.style.display = "none";
  }
};

// Hide loading screen after a short delay to ensure DOM is ready
setTimeout(hideLoadingScreen, 100);

// Also hide loading screen when the DOM is fully loaded
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', hideLoadingScreen);
} else {
  hideLoadingScreen();
}

// Create root and render app
const rootElement = document.getElementById("root");
if (rootElement) {
  ReactDOM.createRoot(rootElement).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} else {
  console.error("Root element not found!");
}