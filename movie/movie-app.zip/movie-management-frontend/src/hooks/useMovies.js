import { useState, useEffect } from 'react';

export const useMovies = (searchTerm = '', sortBy = 'title', page = 1, limit = 20) => {
  const [movies, setMovies] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pagination, setPagination] = useState({
    page: 1,
    limit: 20,
    totalCount: 0,
    totalPages: 0
  });

  useEffect(() => {
    fetchMovies();
  }, [page, limit, searchTerm, sortBy]);

  const fetchMovies = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Build query parameters
      const queryParams = new URLSearchParams();
      queryParams.append('page', page);
      queryParams.append('limit', limit);
      
      if (searchTerm) {
        queryParams.append('search', searchTerm);
      }
      
      if (sortBy) {
        queryParams.append('sortBy', sortBy);
      }
      
      const response = await fetch(`http://localhost:5000/api/movies?${queryParams.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch movies');
      
      const data = await response.json();
      setMovies(data.data || []);
      setPagination({
        page: data.pagination?.page || page,
        limit: data.pagination?.limit || limit,
        totalCount: data.pagination?.totalCount || 0,
        totalPages: data.pagination?.totalPages || Math.ceil((data.pagination?.totalCount || 0) / limit)
      });
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const filteredMovies = movies
    .filter(movie =>
      movie.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (movie.description && movie.description.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'title':
          return a.title.localeCompare(b.title);
        case 'rating':
          return (b.rating || 0) - (a.rating || 0);
        case 'release_date':
          return new Date(b.release_date) - new Date(a.release_date);
        case 'duration':
          return (b.duration_minutes || 0) - (a.duration_minutes || 0);
        default:
          return 0;
      }
    });

  return {
    movies: filteredMovies,
    allMovies: movies,
    loading,
    error,
    refetch: fetchMovies,
    pagination,
    setPage: (newPage) => {
      // This will trigger the useEffect to fetch new data
    }
  };
};

export const useAuth = () => {
  const [user, setUser] = useState(null);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = () => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
      } catch (err) {
        logout();
      }
    }
  };

  const login = (userData, token) => {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
  };

  return {
    user,
    isAuthenticated: !!user,
    login,
    logout,
    checkAuth
  };
};

export const useLocalStorage = (key, initialValue) => {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };

  return [storedValue, setValue];
};