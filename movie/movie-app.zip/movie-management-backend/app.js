const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const rateLimit = require("express-rate-limit");
require("dotenv").config();

const logger = require("./utils/logger");

const app = express();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: false, // Disable for API
  crossOriginEmbedderPolicy: false
}));

// Rate limiting
// Temporarily disable rate limiting for testing
// const limiter = rateLimit({
//   windowMs: 15 * 60 * 1000, // 15 minutes
//   max: 5000, // Increased limit to 5000 requests per windowMs to avoid connection issues during development
//   message: 'Too many requests from this IP, please try again later.',
//   standardHeaders: true,
//   legacyHeaders: false,
// });
// app.use('/api/', limiter);

// CORS configuration - Allow all origins for development
app.use(cors());

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Request logging
if (process.env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined', {
    stream: {
      write: (message) => logger.info(message.trim())
    }
  }));
}

// API Index - helpful response for /api (must be before other /api routes)
app.get("/api", (req, res) => {
  res.json({
    success: true,
    message: "CineMaster Pro API v2.0",
    version: "2.0.0",
    endpoints: {
      health: {
        url: "/health",
        method: "GET",
        description: "Server health check"
      },
      movies: {
        getAll: "GET /api/movies",
        getById: "GET /api/movies/:id",
        create: "POST /api/movies (auth required)",
        update: "PUT /api/movies/:id (auth required)",
        delete: "DELETE /api/movies/:id (auth required)",
        query: "GET /api/movies?page=1&limit=20&search=keyword"
      },
      reviews: {
        getMovieReviews: "GET /api/reviews/movie/:movieId",
        addReview: "POST /api/reviews/movie/:movieId (auth required)",
        updateReview: "PUT /api/reviews/:reviewId (auth required)",
        deleteReview: "DELETE /api/reviews/:reviewId (auth required)",
        getUserReview: "GET /api/reviews/movie/:movieId/user (auth required)"
      },
      collections: {
        getUserCollections: "GET /api/collections (auth required)",
        createCollection: "POST /api/collections (auth required)",
        getCollection: "GET /api/collections/:collectionId (auth required)",
        updateCollection: "PUT /api/collections/:collectionId (auth required)",
        deleteCollection: "DELETE /api/collections/:collectionId (auth required)",
        addMovieToCollection: "POST /api/collections/:collectionId/movies (auth required)",
        removeMovieFromCollection: "DELETE /api/collections/:collectionId/movies/:movieId (auth required)",
        getPublicCollections: "GET /api/collections/public"
      },
      stats: {
        getStats: "GET /api/stats",
        getUserStats: "GET /api/stats/user (auth required)",
        getRecentActivity: "GET /api/stats/activity"
      },
      auth: {
        register: "POST /api/auth/register",
        login: "POST /api/auth/login"
      },
      users: {
        base: "GET /api/users"
      }
    },
    documentation: "See README.md for full API documentation",
    timestamp: new Date().toISOString()
  });
});

// Routes
app.use("/api/movies", require("./routes/movies"));
app.use("/api/auth", require("./routes/auth"));
app.use("/api/users", require("./routes/users"));
app.use("/api/reviews", require("./routes/reviews"));
app.use("/api/collections", require("./routes/collections"));
app.use("/api/stats", require("./routes/stats"));

// Health check
app.get("/health", (req, res) => {
  res.json({
    status: "OK",
    message: "Movie Management API is running",
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
    version: '2.0.0'
  });
});

// Root route
app.get("/", (req, res) => {
  res.json({
    message: "Welcome to Movie Management API",
    endpoints: {
      health: "/health",
      movies: "/api/movies",
      auth: "/api/auth",
      users: "/api/users",
    },
  });
});

// 404 handler
app.use((req, res) => {
  logger.warn(`404 - Route not found: ${req.method} ${req.originalUrl}`);
  res.status(404).json({
    success: false,
    message: "API endpoint not found",
    requestedUrl: req.originalUrl,
    availableEndpoints: {
      health: "/health",
      movies: "/api/movies",
      auth: "/api/auth",
      users: "/api/users",
      reviews: "/api/reviews",
      collections: "/api/collections",
      stats: "/api/stats"
    }
  });
});

// Error handler
app.use((err, req, res, next) => {
  logger.error('Server Error:', {
    message: err.message,
    stack: err.stack,
    url: req.originalUrl,
    method: req.method
  });

  const statusCode = err.statusCode || 500;
  
  res.status(statusCode).json({
    success: false,
    message: err.message || "Internal server error",
    ...(process.env.NODE_ENV === "development" && { 
      error: err.message,
      stack: err.stack 
    })
  });
});

const PORT = process.env.PORT || 5000;
const HOST = process.env.HOST || '0.0.0.0'; // Listen on all interfaces for mobile access

// Graceful shutdown
const server = app.listen(PORT, HOST, () => {
  logger.info(`✅ Backend server running on port ${PORT}`);
  logger.info(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
  logger.info(`📍 Health check: http://localhost:${PORT}/health`);
  logger.info(`📍 API base: http://localhost:${PORT}/api`);
  
  // Also log the network IP for mobile access
  const interfaces = require('os').networkInterfaces();
  Object.keys(interfaces).forEach(interfaceName => {
    interfaces[interfaceName].forEach(interface => {
      if (!interface.internal && interface.family === 'IPv4') {
        logger.info(`📱 Mobile access: http://${interface.address}:${PORT}`);
      }
    });
  });
});

process.on('SIGTERM', () => {
  logger.info('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  logger.info('SIGINT signal received: closing HTTP server');
  server.close(() => {
    logger.info('HTTP server closed');
    process.exit(0);
  });
});
