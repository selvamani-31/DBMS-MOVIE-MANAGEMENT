-- Database Functions and Triggers for CineMaster Pro

-- 1. Function to automatically update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 2. Function to calculate average movie rating
CREATE OR REPLACE FUNCTION calculate_movie_average_rating(movie_uuid UUID)
RETURNS NUMERIC AS $$
DECLARE
    avg_rating NUMERIC;
BEGIN
    SELECT COALESCE(ROUND(AVG(rating), 1), 0)
    INTO avg_rating
    FROM reviews
    WHERE movie_id = movie_uuid;
    
    RETURN avg_rating;
END;
$$ LANGUAGE plpgsql;

-- 3. Function to get movie review count
CREATE OR REPLACE FUNCTION get_movie_review_count(movie_uuid UUID)
RETURNS INTEGER AS $$
DECLARE
    review_count INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO review_count
    FROM reviews
    WHERE movie_id = movie_uuid;
    
    RETURN review_count;
END;
$$ LANGUAGE plpgsql;

-- 4. Function to update movie rating after review changes
CREATE OR REPLACE FUNCTION update_movie_rating()
RETURNS TRIGGER AS $$
BEGIN
    -- Update the movie's rating based on all reviews
    UPDATE movies 
    SET rating = (
        SELECT COALESCE(ROUND(AVG(rating), 1), 0)
        FROM reviews
        WHERE movie_id = COALESCE(NEW.movie_id, OLD.movie_id)
    )
    WHERE movie_id = COALESCE(NEW.movie_id, OLD.movie_id);
    
    RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql;

-- 5. Function to prevent duplicate collection movies
CREATE OR REPLACE FUNCTION prevent_duplicate_collection_movies()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if this movie is already in this collection
    IF EXISTS (
        SELECT 1 FROM collection_movies 
        WHERE collection_id = NEW.collection_id 
        AND movie_id = NEW.movie_id
    ) THEN
        RAISE EXCEPTION 'Movie already exists in this collection';
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- TRIGGERS

-- 1. Trigger to automatically update updated_at for users table
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 2. Trigger to automatically update updated_at for movies table
DROP TRIGGER IF EXISTS update_movies_updated_at ON movies;
CREATE TRIGGER update_movies_updated_at
    BEFORE UPDATE ON movies
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 3. Trigger to automatically update updated_at for collections table
DROP TRIGGER IF EXISTS update_collections_updated_at ON collections;
CREATE TRIGGER update_collections_updated_at
    BEFORE UPDATE ON collections
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 4. Trigger to update movie rating when reviews are added/updated/deleted
DROP TRIGGER IF EXISTS update_movie_rating_trigger ON reviews;
CREATE TRIGGER update_movie_rating_trigger
    AFTER INSERT OR UPDATE OR DELETE ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_movie_rating();

-- 5. Trigger to prevent duplicate movies in collections
DROP TRIGGER IF EXISTS prevent_duplicate_collection_movies_trigger ON collection_movies;
CREATE TRIGGER prevent_duplicate_collection_movies_trigger
    BEFORE INSERT ON collection_movies
    FOR EACH ROW
    EXECUTE FUNCTION prevent_duplicate_collection_movies();

-- 6. Trigger to automatically set created_at for new reviews
DROP TRIGGER IF EXISTS set_review_created_at ON reviews;
CREATE TRIGGER set_review_created_at
    BEFORE INSERT ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- 7. Trigger to automatically update updated_at for reviews
DROP TRIGGER IF EXISTS update_reviews_updated_at ON reviews;
CREATE TRIGGER update_reviews_updated_at
    BEFORE UPDATE ON reviews
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- INDEXES for better performance
CREATE INDEX IF NOT EXISTS idx_movies_title ON movies(title);
CREATE INDEX IF NOT EXISTS idx_movies_rating ON movies(rating);
CREATE INDEX IF NOT EXISTS idx_reviews_movie_id ON reviews(movie_id);
CREATE INDEX IF NOT EXISTS idx_reviews_user_id ON reviews(user_id);
CREATE INDEX IF NOT EXISTS idx_collection_movies_collection_id ON collection_movies(collection_id);
CREATE INDEX IF NOT EXISTS idx_collection_movies_movie_id ON collection_movies(movie_id);