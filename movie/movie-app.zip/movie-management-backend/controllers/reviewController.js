const logger = require('../utils/logger');

const reviewController = {
  // Get all reviews for a movie
  getMovieReviews: async (req, res) => {
    try {
      const { movieId } = req.params;
      const db = require("../config/database");
      
      const query = `
        SELECT 
          r.*,
          u.username,
          u.first_name,
          u.last_name
        FROM reviews r
        JOIN users u ON r.user_id = u.user_id
        WHERE r.movie_id = $1
        ORDER BY r.created_at DESC
      `;
      
      const result = await db.query(query, [movieId]);
      const reviews = result.rows;
      
      res.json({
        success: true,
        data: reviews,
        count: reviews.length
      });
    } catch (error) {
      logger.error("Error in getMovieReviews:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching reviews",
        error: error.message,
      });
    }
  },

  // Add a review for a movie
  addReview: async (req, res) => {
    try {
      const { movieId } = req.params;
      const { rating, comment } = req.body;
      const userId = req.user.userId; // From auth middleware
      
      // Validation
      if (!rating || rating < 1 || rating > 10) {
        return res.status(400).json({
          success: false,
          message: "Rating must be between 1 and 10",
        });
      }
      
      if (!comment || comment.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Comment is required",
        });
      }
      
      if (comment.trim().length > 1000) {
        return res.status(400).json({
          success: false,
          message: "Comment must be less than 1000 characters",
        });
      }
      
      const db = require("../config/database");
      
      // Check if user already reviewed this movie
      const existingReview = await db.query(
        'SELECT review_id FROM reviews WHERE user_id = $1 AND movie_id = $2',
        [userId, movieId]
      );
      
      if (existingReview.rows.length > 0) {
        return res.status(400).json({
          success: false,
          message: "You have already reviewed this movie",
        });
      }
      
      // Insert the review
      const query = `
        INSERT INTO reviews (user_id, movie_id, rating, comment)
        VALUES ($1, $2, $3, $4)
        RETURNING *
      `;
      
      const result = await db.query(query, [userId, movieId, rating, comment.trim()]);
      const newReview = result.rows[0];
      
      logger.info(`Review added for movie ${movieId} by user ${userId}`);
      
      res.status(201).json({
        success: true,
        message: "Review added successfully",
        data: newReview,
      });
    } catch (error) {
      logger.error("Error in addReview:", error);
      res.status(500).json({
        success: false,
        message: "Error adding review",
        error: error.message,
      });
    }
  },

  // Update a review
  updateReview: async (req, res) => {
    try {
      const { reviewId } = req.params;
      const { rating, comment } = req.body;
      const userId = req.user.userId; // From auth middleware
      
      // Validation
      if (!rating || rating < 1 || rating > 10) {
        return res.status(400).json({
          success: false,
          message: "Rating must be between 1 and 10",
        });
      }
      
      if (!comment || comment.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Comment is required",
        });
      }
      
      if (comment.trim().length > 1000) {
        return res.status(400).json({
          success: false,
          message: "Comment must be less than 1000 characters",
        });
      }
      
      const db = require("../config/database");
      
      // Check if review exists and belongs to user
      const reviewCheck = await db.query(
        'SELECT review_id FROM reviews WHERE review_id = $1 AND user_id = $2',
        [reviewId, userId]
      );
      
      if (reviewCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Review not found or you don't have permission to edit it",
        });
      }
      
      // Update the review
      const query = `
        UPDATE reviews 
        SET rating = $1, comment = $2, updated_at = CURRENT_TIMESTAMP
        WHERE review_id = $3
        RETURNING *
      `;
      
      const result = await db.query(query, [rating, comment.trim(), reviewId]);
      const updatedReview = result.rows[0];
      
      logger.info(`Review ${reviewId} updated by user ${userId}`);
      
      res.json({
        success: true,
        message: "Review updated successfully",
        data: updatedReview,
      });
    } catch (error) {
      logger.error("Error in updateReview:", error);
      res.status(500).json({
        success: false,
        message: "Error updating review",
        error: error.message,
      });
    }
  },

  // Delete a review
  deleteReview: async (req, res) => {
    try {
      const { reviewId } = req.params;
      const userId = req.user.userId; // From auth middleware
      
      const db = require("../config/database");
      
      // Check if review exists and belongs to user (or user is admin)
      const reviewCheck = await db.query(
        'SELECT review_id FROM reviews WHERE review_id = $1 AND (user_id = $2 OR $3 = true)',
        [reviewId, userId, req.user.is_admin || false]
      );
      
      if (reviewCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Review not found or you don't have permission to delete it",
        });
      }
      
      // Delete the review
      const query = 'DELETE FROM reviews WHERE review_id = $1 RETURNING *';
      const result = await db.query(query, [reviewId]);
      const deletedReview = result.rows[0];
      
      logger.info(`Review ${reviewId} deleted by user ${userId}`);
      
      res.json({
        success: true,
        message: "Review deleted successfully",
        data: deletedReview,
      });
    } catch (error) {
      logger.error("Error in deleteReview:", error);
      res.status(500).json({
        success: false,
        message: "Error deleting review",
        error: error.message,
      });
    }
  },

  // Get user's review for a specific movie
  getUserReview: async (req, res) => {
    try {
      const { movieId } = req.params;
      const userId = req.user.userId; // From auth middleware
      
      const db = require("../config/database");
      
      const query = `
        SELECT *
        FROM reviews
        WHERE user_id = $1 AND movie_id = $2
      `;
      
      const result = await db.query(query, [userId, movieId]);
      const review = result.rows[0];
      
      if (!review) {
        return res.json({
          success: true,
          data: null,
        });
      }
      
      res.json({
        success: true,
        data: review,
      });
    } catch (error) {
      logger.error("Error in getUserReview:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching user review",
        error: error.message,
      });
    }
  },
};

module.exports = reviewController;