const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/userModel");
const logger = require('../utils/logger');

const authController = {
  register: async (req, res) => {
    try {
      const { username, email, password, first_name, last_name } = req.body;

      logger.info(`Registration attempt for email: ${email}`);

      // Simple validation
      if (!username || !email || !password) {
        return res.status(400).json({
          success: false,
          message: "Username, email and password are required",
        });
      }

      // Password strength check
      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message: "Password must be at least 6 characters long",
        });
      }

      // Check if user exists
      const existingUser = await User.findByEmail(email);
      if (existingUser) {
        logger.warn(`Registration failed: Email already exists - ${email}`);
        return res.status(400).json({
          success: false,
          message: "User already exists with this email",
        });
      }

      // Hash password
      const saltRounds = 10;
      const passwordHash = await bcrypt.hash(password, saltRounds);

      // Create user
      const newUser = await User.create({
        username,
        email,
        password_hash: passwordHash,
        first_name,
        last_name,
      });

      // Generate token with explicit expiration
      const token = jwt.sign(
        { userId: newUser.user_id, role: newUser.role },
        process.env.JWT_SECRET || "your-secret-key",
        { expiresIn: "24h" }
      );

      logger.info(`User registered successfully: ${email}`);

      res.status(201).json({
        success: true,
        message: "User registered successfully",
        data: {
          user: newUser,
          token,
        },
      });
    } catch (error) {
      logger.error("Registration error:", error);
      res.status(500).json({
        success: false,
        message: "Error registering user",
        error: error.message,
      });
    }
  },

  login: async (req, res) => {
    try {
      const { email, password } = req.body;

      logger.info(`Login attempt for email: ${email}`);

      // Simple validation
      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message: "Email and password are required",
        });
      }

      // Find user
      const user = await User.findByEmail(email);
      if (!user) {
        logger.warn(`Login failed: User not found - ${email}`);
        return res.status(401).json({
          success: false,
          message: "Invalid email or password",
        });
      }

      // Check password
      const isValidPassword = await bcrypt.compare(
        password,
        user.password_hash
      );
      if (!isValidPassword) {
        logger.warn(`Login failed: Invalid password - ${email}`);
        return res.status(401).json({
          success: false,
          message: "Invalid email or password",
        });
      }

      // Generate token with explicit expiration
      const token = jwt.sign(
        { userId: user.user_id, role: user.role },
        process.env.JWT_SECRET || "your-secret-key",
        { expiresIn: "24h" }
      );

      // Return user data without password
      const userWithoutPassword = {
        user_id: user.user_id,
        username: user.username,
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        role: user.role,
        created_at: user.created_at,
      };

      logger.info(`Login successful: ${email}`);

      res.json({
        success: true,
        message: "Login successful",
        data: {
          user: userWithoutPassword,
          token,
        },
      });
    } catch (error) {
      logger.error("Login error:", error);
      res.status(500).json({
        success: false,
        message: "Error logging in",
        error: error.message,
      });
    }
  },

  refreshToken: async (req, res) => {
    try {
      // If we reach this point, the user is authenticated
      // Generate a new token with extended expiration
      const token = jwt.sign(
        { userId: req.user.userId, role: req.user.role },
        process.env.JWT_SECRET || "your-secret-key",
        { expiresIn: "24h" }
      );

      res.json({
        success: true,
        message: "Token refreshed successfully",
        data: {
          token,
        },
      });
    } catch (error) {
      logger.error("Token refresh error:", error);
      res.status(500).json({
        success: false,
        message: "Error refreshing token",
        error: error.message,
      });
    }
  },
};

module.exports = authController;