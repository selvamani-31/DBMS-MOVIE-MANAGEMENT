const logger = require('../utils/logger');

const statsController = {
  // Get overall statistics
  getStats: async (req, res) => {
    try {
      const db = require("../config/database");
      
      // Get total movies count
      const moviesCount = await db.query('SELECT COUNT(*) as count FROM movies');
      
      // Get total users count
      const usersCount = await db.query('SELECT COUNT(*) as count FROM users');
      
      // Get total reviews count
      const reviewsCount = await db.query('SELECT COUNT(*) as count FROM reviews');
      
      // Get total collections count
      const collectionsCount = await db.query('SELECT COUNT(*) as count FROM collections');
      
      // Get average movie rating
      const avgRating = await db.query(`
        SELECT COALESCE(AVG(rating), 0) as avg_rating 
        FROM movies 
        WHERE rating IS NOT NULL
      `);
      
      // Get top rated movies (limit 5)
      const topRatedMovies = await db.query(`
        SELECT 
          movie_id,
          title,
          rating,
          poster_url
        FROM movies 
        WHERE rating IS NOT NULL
        ORDER BY rating DESC
        LIMIT 5
      `);
      
      // Get most reviewed movies (limit 5)
      const mostReviewedMovies = await db.query(`
        SELECT 
          m.movie_id,
          m.title,
          m.poster_url,
          COUNT(r.review_id) as review_count,
          COALESCE(AVG(r.rating), 0) as avg_rating
        FROM movies m
        LEFT JOIN reviews r ON m.movie_id = r.movie_id
        GROUP BY m.movie_id, m.title, m.poster_url
        HAVING COUNT(r.review_id) > 0
        ORDER BY COUNT(r.review_id) DESC
        LIMIT 5
      `);
      
      // Get movies by genre distribution
      const genreDistribution = await db.query(`
        SELECT 
          g.genre_name,
          COUNT(mg.movie_id) as count
        FROM genres g
        LEFT JOIN movie_genres mg ON g.genre_id = mg.genre_id
        GROUP BY g.genre_name
        ORDER BY COUNT(mg.movie_id) DESC
        LIMIT 10
      `);
      
      // Get movies by year distribution (last 10 years)
      const currentYear = new Date().getFullYear();
      const tenYearsAgo = currentYear - 9;
      
      const yearDistribution = await db.query(`
        SELECT 
          EXTRACT(YEAR FROM release_date) as year,
          COUNT(*) as count
        FROM movies 
        WHERE EXTRACT(YEAR FROM release_date) >= $1
        GROUP BY EXTRACT(YEAR FROM release_date)
        ORDER BY EXTRACT(YEAR FROM release_date)
      `, [tenYearsAgo]);
      
      res.json({
        success: true,
        data: {
          totals: {
            movies: parseInt(moviesCount.rows[0].count),
            users: parseInt(usersCount.rows[0].count),
            reviews: parseInt(reviewsCount.rows[0].count),
            collections: parseInt(collectionsCount.rows[0].count),
            averageRating: parseFloat(avgRating.rows[0].avg_rating).toFixed(1)
          },
          topRatedMovies: topRatedMovies.rows,
          mostReviewedMovies: mostReviewedMovies.rows,
          genreDistribution: genreDistribution.rows,
          yearDistribution: yearDistribution.rows
        }
      });
    } catch (error) {
      logger.error("Error in getStats:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching statistics",
        error: error.message,
      });
    }
  },

  // Get user-specific statistics (if authenticated)
  getUserStats: async (req, res) => {
    try {
      const userId = req.user.user_id; // From auth middleware
      
      const db = require("../config/database");
      
      // Get user's reviews count
      const userReviewsCount = await db.query(
        'SELECT COUNT(*) as count FROM reviews WHERE user_id = $1',
        [userId]
      );
      
      // Get user's collections count
      const userCollectionsCount = await db.query(
        'SELECT COUNT(*) as count FROM collections WHERE user_id = $1',
        [userId]
      );
      
      // Get user's average rating given
      const userAvgRating = await db.query(`
        SELECT COALESCE(AVG(rating), 0) as avg_rating 
        FROM reviews 
        WHERE user_id = $1
      `, [userId]);
      
      // Get user's favorite genres (based on movies in collections)
      const userFavoriteGenres = await db.query(`
        SELECT 
          g.genre_name,
          COUNT(*) as count
        FROM collections c
        JOIN collection_movies cm ON c.collection_id = cm.collection_id
        JOIN movie_genres mg ON cm.movie_id = mg.movie_id
        JOIN genres g ON mg.genre_id = g.genre_id
        WHERE c.user_id = $1
        GROUP BY g.genre_name
        ORDER BY COUNT(*) DESC
        LIMIT 5
      `, [userId]);
      
      res.json({
        success: true,
        data: {
          user: {
            reviewsWritten: parseInt(userReviewsCount.rows[0].count),
            collectionsCreated: parseInt(userCollectionsCount.rows[0].count),
            averageRatingGiven: parseFloat(userAvgRating.rows[0].avg_rating).toFixed(1),
            favoriteGenres: userFavoriteGenres.rows
          }
        }
      });
    } catch (error) {
      logger.error("Error in getUserStats:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching user statistics",
        error: error.message,
      });
    }
  },

  // Get recent activity
  getRecentActivity: async (req, res) => {
    try {
      const { limit = 10 } = req.query;
      
      const db = require("../config/database");
      
      // Get recent movie additions (without user information since there's no created_by column)
      const recentMovies = await db.query(`
        SELECT 
          m.movie_id,
          m.title,
          m.poster_url,
          m.created_at
        FROM movies m
        ORDER BY m.created_at DESC
        LIMIT $1
      `, [parseInt(limit)]);
      
      // Get recent reviews
      const recentReviews = await db.query(`
        SELECT 
          r.review_id,
          r.rating,
          r.comment,
          r.created_at,
          u.username as reviewer,
          m.title as movie_title,
          m.movie_id as movie_id
        FROM reviews r
        JOIN users u ON r.user_id = u.user_id
        JOIN movies m ON r.movie_id = m.movie_id
        ORDER BY r.created_at DESC
        LIMIT $1
      `, [parseInt(limit)]);
      
      // Get recent collections
      const recentCollections = await db.query(`
        SELECT 
          c.collection_id,
          c.name,
          c.created_at,
          u.username as creator,
          COUNT(cm.movie_id) as movie_count
        FROM collections c
        JOIN users u ON c.user_id = u.user_id
        LEFT JOIN collection_movies cm ON c.collection_id = cm.collection_id
        WHERE c.is_public = true
        GROUP BY c.collection_id, c.name, c.created_at, u.username
        ORDER BY c.created_at DESC
        LIMIT $1
      `, [parseInt(limit)]);
      
      res.json({
        success: true,
        data: {
          recentMovies: recentMovies.rows,
          recentReviews: recentReviews.rows,
          recentCollections: recentCollections.rows
        }
      });
    } catch (error) {
      logger.error("Error in getRecentActivity:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching recent activity",
        error: error.message,
      });
    }
  }
};

module.exports = statsController;