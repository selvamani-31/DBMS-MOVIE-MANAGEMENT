const Movie = require("../models/movieModel");
const logger = require('../utils/logger');

const movieController = {
  // Get all movies - ENHANCED with advanced search and filtering
  getAllMovies: async (req, res) => {
    try {
      const { 
        page = 1, 
        limit = 20, 
        search = '',
        genre = '',
        year = '',
        rating = '',
        sortBy
      } = req.query;
      
      // Handle combined sort parameter (e.g., "title-asc", "rating-desc")
      let actualSortBy = null;
      let actualSortOrder = null;
      
      // If sortBy contains a combined value like "title-asc", parse it
      if (sortBy && sortBy.includes('-')) {
        const parts = sortBy.split('-');
        if (parts.length === 2) {
          actualSortBy = parts[0];
          actualSortOrder = parts[1];
        }
      } else if (sortBy) {
        // If we have a sortBy but no order, default to asc
        actualSortBy = sortBy;
        actualSortOrder = 'asc';
      }
      
      const db = require("../config/database");
      const offset = (parseInt(page) - 1) * parseInt(limit);
      
      // First get the total count of movies matching the filters
      let countQuery = `
        SELECT COUNT(DISTINCT m.movie_id) as total_count
        FROM movies m
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
      `;
      
      const countParams = [];
      let countParamIndex = 1;
      
      // Add WHERE conditions for counting
      const countWhereConditions = [];
      
      if (search) {
        countWhereConditions.push(`(m.title ILIKE $${countParamIndex} OR m.description ILIKE $${countParamIndex})`);
        countParams.push(`%${search}%`);
        countParamIndex++;
      }
      
      if (year) {
        countWhereConditions.push(`EXTRACT(YEAR FROM m.release_date) = $${countParamIndex}`);
        countParams.push(year);
        countParamIndex++;
      }
      
      // Add genre filtering condition for count query
      if (genre && genre !== 'all') {
        countWhereConditions.push(`g.genre_name = $${countParamIndex}`);
        countParams.push(genre);
        countParamIndex++;
      }
      
      // Add WHERE clause if we have conditions for count query
      if (countWhereConditions.length > 0) {
        countQuery += ` WHERE ${countWhereConditions.join(' AND ')}`;
      }
      
      const countResult = await db.query(countQuery, countParams);
      const totalCount = parseInt(countResult.rows[0]?.total_count || 0);
      const totalPages = Math.ceil(totalCount / parseInt(limit));
      
      // First get the basic movie data with proper sorting
      const sortFields = {
        'title': 'm.title',
        'release_date': 'm.release_date',
        'rating': 'm.rating',
        'duration_minutes': 'm.duration_minutes',
        'genres': 'genres_list' // Special handling for genres
      };
      
      // Base query with genre aggregation
      let baseQuery = `
        SELECT 
          m.*,
          COALESCE(m.rating, 0) as display_rating,
          STRING_AGG(DISTINCT g.genre_name, ', ' ORDER BY g.genre_name) as genres_list
        FROM movies m
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
      `;
      
      const baseParams = [];
      let baseParamIndex = 1;
      
      // Add WHERE conditions for basic filtering (before GROUP BY)
      const whereConditions = [];
      
      if (search) {
        whereConditions.push(`(m.title ILIKE $${baseParamIndex} OR m.description ILIKE $${baseParamIndex})`);
        baseParams.push(`%${search}%`);
        baseParamIndex++;
      }
      
      if (year) {
        whereConditions.push(`EXTRACT(YEAR FROM m.release_date) = $${baseParamIndex}`);
        baseParams.push(year);
        baseParamIndex++;
      }
      
      // Add genre filtering condition (before GROUP BY for better performance)
      if (genre && genre !== 'all') {
        whereConditions.push(`g.genre_name = $${baseParamIndex}`);
        baseParams.push(genre);
        baseParamIndex++;
      }
      
      // Add WHERE clause if we have conditions
      if (whereConditions.length > 0) {
        baseQuery += ` WHERE ${whereConditions.join(' AND ')}`;
      }
      
      // Group by movie fields for aggregation
      baseQuery += `
        GROUP BY m.movie_id, m.title, m.description, m.release_date, m.duration_minutes, m.rating, m.poster_url, m.trailer_url, m.created_at, m.updated_at
      `;
      
      // Add ORDER BY clause only if sorting is specified
      if (actualSortBy && actualSortOrder) {
        const sortField = sortFields[actualSortBy] || 'm.title';
        const sortDirection = actualSortOrder.toLowerCase() === 'desc' ? 'DESC' : 'ASC';
        
        // Special handling for genres sorting
        if (actualSortBy === 'genres') {
          baseQuery += `
            ORDER BY genres_list ${sortDirection}, m.title ASC
          `;
        } else {
          baseQuery += `
            ORDER BY ${sortField} ${sortDirection}
          `;
        }
      } else {
        // Default order by title if no sorting specified
        baseQuery += `
          ORDER BY m.title ASC
        `;
      }
      
      baseQuery += `
        LIMIT $${baseParamIndex} OFFSET $${baseParamIndex + 1}
      `;
      
      baseParams.push(parseInt(limit), offset);

      const baseResult = await db.query(baseQuery, baseParams);
      const movies = baseResult.rows;

      // Process movies to format genres as array
      const processedMovies = movies.map(movie => {
        // Convert genres_list string back to array
        movie.genres = movie.genres_list ? movie.genres_list.split(', ').map(g => g.trim()) : [];
        // Remove the temporary genres_list field
        delete movie.genres_list;
        // Set other computed fields
        movie.average_rating = parseFloat(movie.display_rating || 0);
        movie.review_count = 0; // Will be set below
        return movie;
      });

      // Now enrich each movie with ratings from reviews
      const enrichedMovies = [];
      for (const movie of processedMovies) {
        // Get average rating from reviews
        const ratingQuery = `
          SELECT 
            COALESCE(AVG(rating), 0) as average_rating,
            COUNT(review_id) as review_count
          FROM reviews
          WHERE movie_id = $1
        `;
        
        const ratingResult = await db.query(ratingQuery, [movie.movie_id]);
        movie.average_rating = parseFloat(ratingResult.rows[0]?.average_rating || 0);
        movie.review_count = parseInt(ratingResult.rows[0]?.review_count || 0);
        
        enrichedMovies.push(movie);
      }

      res.json({
        success: true,
        data: enrichedMovies,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          totalCount: totalCount,
          totalPages: totalPages,
          count: enrichedMovies.length
        }
      });
    } catch (error) {
      logger.error("Error in getAllMovies:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching movies",
        error: error.message,
      });
    }
  },

  // Get movie by ID - ENHANCED
  getMovieById: async (req, res) => {
    try {
      const { id } = req.params;
      logger.debug(`Fetching movie with ID: ${id}`);
      
      const db = require("../config/database");

      // Enhanced query to get more detailed movie information
      const query = `
        SELECT 
          m.*,
          ARRAY_AGG(DISTINCT g.genre_name) as genres,
          ARRAY_AGG(DISTINCT CONCAT(a.first_name, ' ', a.last_name)) as actors,
          ARRAY_AGG(DISTINCT CONCAT(d.first_name, ' ', d.last_name)) as directors,
          COALESCE(AVG(r.rating), 0) as average_rating,
          COUNT(r.review_id) as review_count
        FROM movies m
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
        LEFT JOIN movie_actors ma ON m.movie_id = ma.movie_id
        LEFT JOIN actors a ON ma.actor_id = a.actor_id
        LEFT JOIN movie_directors md ON m.movie_id = md.movie_id
        LEFT JOIN directors d ON md.director_id = d.director_id
        LEFT JOIN reviews r ON m.movie_id = r.movie_id
        WHERE m.movie_id = $1
        GROUP BY m.movie_id
      `;

      const result = await db.query(query, [id]);

      if (result.rows.length === 0) {
        logger.warn(`Movie not found: ${id}`);
        return res.status(404).json({
          success: false,
          message: "Movie not found",
        });
      }

      // Clean up the data - remove null values from arrays
      const movie = result.rows[0];
      console.log("Raw movie data from DB:", JSON.stringify(movie, null, 2)); // Debug log
      
      if (movie.genres && movie.genres.length > 0) {
        // Filter out null values and empty strings
        movie.genres = movie.genres.filter(g => g !== null && g.trim() !== '');
        // If after filtering we have no genres, set to empty array
        if (movie.genres.length === 0) {
          movie.genres = [];
        }
      } else {
        movie.genres = [];
      }
      
      if (movie.actors && movie.actors.length > 0) {
        // Filter out null values and empty strings
        movie.actors = movie.actors.filter(a => a !== null && a.trim() !== '');
        // If after filtering we have no actors, set to empty array
        if (movie.actors.length === 0) {
          movie.actors = [];
        }
      } else {
        movie.actors = [];
      }
      
      if (movie.directors && movie.directors.length > 0) {
        // Filter out null values and empty strings
        movie.directors = movie.directors.filter(d => d !== null && d.trim() !== '');
        // If after filtering we have no directors, set to empty array
        if (movie.directors.length === 0) {
          movie.directors = [];
        }
      } else {
        movie.directors = [];
      }

      logger.info(`Movie found: ${id}`);
      console.log("Cleaned movie data:", JSON.stringify(movie, null, 2)); // Debug log
      res.json({
        success: true,
        data: movie,
      });
    } catch (error) {
      logger.error("Error in getMovieById:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching movie",
        error: error.message,
      });
    }
  },

  // Get related movies based on genres, actors, or directors
  getRelatedMovies: async (req, res) => {
    try {
      const { id } = req.params;
      const { limit = 6 } = req.query;
      
      logger.debug(`Fetching related movies for ID: ${id}`);
      
      const db = require("../config/database");

      // First get the current movie's details
      const currentMovieQuery = `
        SELECT 
          m.*,
          ARRAY_AGG(DISTINCT g.genre_name) as genres,
          ARRAY_AGG(DISTINCT CONCAT(a.first_name, ' ', a.last_name)) as actors,
          ARRAY_AGG(DISTINCT CONCAT(d.first_name, ' ', d.last_name)) as directors
        FROM movies m
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
        LEFT JOIN movie_actors ma ON m.movie_id = ma.movie_id
        LEFT JOIN actors a ON ma.actor_id = a.actor_id
        LEFT JOIN movie_directors md ON m.movie_id = md.movie_id
        LEFT JOIN directors d ON md.director_id = d.director_id
        WHERE m.movie_id = $1
        GROUP BY m.movie_id
      `;

      const currentMovieResult = await db.query(currentMovieQuery, [id]);
      
      if (currentMovieResult.rows.length === 0) {
        logger.warn(`Movie not found for related movies: ${id}`);
        return res.status(404).json({
          success: false,
          message: "Movie not found",
        });
      }

      const currentMovie = currentMovieResult.rows[0];
      
      // Clean up arrays
      const genres = currentMovie.genres ? currentMovie.genres.filter(g => g !== null) : [];
      const actors = currentMovie.actors ? currentMovie.actors.filter(a => a !== null) : [];
      const directors = currentMovie.directors ? currentMovie.directors.filter(d => d !== null) : [];

      // Simple approach: Get movies with similar genres
      let relatedQuery = `
        SELECT DISTINCT 
          m.*,
          ARRAY_AGG(DISTINCT g.genre_name) as genres,
          COALESCE(AVG(r.rating), 0) as average_rating,
          COUNT(r.review_id) as review_count
        FROM movies m
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
        LEFT JOIN reviews r ON m.movie_id = r.movie_id
        WHERE m.movie_id != $1
      `;
      
      const queryParams = [id];
      
      // Add condition for shared genres if we have them
      let paramIndex = 2;
      if (genres.length > 0) {
        relatedQuery += ` AND g.genre_name = ANY($${paramIndex}::text[])`;
        queryParams.push(genres);
        paramIndex++;
      }
      
      relatedQuery += `
        GROUP BY m.movie_id
        ORDER BY COALESCE(AVG(r.rating), 0) DESC
        LIMIT $${paramIndex}
      `;
      
      queryParams.push(parseInt(limit));

      const relatedResult = await db.query(relatedQuery, queryParams);
      
      // Clean up related movies data
      const relatedMovies = relatedResult.rows.map(movie => {
        if (movie.genres && movie.genres.length > 0) {
          movie.genres = movie.genres.filter(g => g !== null);
          if (movie.genres.length === 0) {
            movie.genres = [];
          }
        } else {
          movie.genres = [];
        }
        return movie;
      });

      logger.info(`Found ${relatedMovies.length} related movies for movie ID: ${id}`);
      
      res.json({
        success: true,
        data: relatedMovies,
      });
    } catch (error) {
      logger.error("Error in getRelatedMovies:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching related movies",
        error: error.message,
      });
    }
  },

  // Create new movie - ENHANCED with trailer support and duplicate prevention
  createMovie: async (req, res) => {
    try {
      let { title, description, release_date, duration_minutes, rating, poster_url, trailer_url, auto_fetch } =
        req.body;

      // Validation - only title is required when auto_fetch is enabled
      if (!title) {
        return res.status(400).json({
          success: false,
          message: "Title is required",
        });
      }

      // Only validate other fields if auto_fetch is disabled
      if (!auto_fetch) {
        if (!description) {
          return res.status(400).json({
            success: false,
            message: "Description is required",
          });
        }
        if (!release_date) {
          return res.status(400).json({
            success: false,
            message: "Release date is required",
          });
        }
        if (!duration_minutes) {
          return res.status(400).json({
            success: false,
            message: "Duration is required",
          });
        }
      }

      logger.info(`Creating movie: ${title}`);

      // If auto_fetch is enabled, fetch additional data
      if (auto_fetch) {
        try {
          const movieDataService = require('../services/movieDataService');
          const movieInfo = await movieDataService.getMovieInfo(title);
          
          // Use fetched data to populate fields
          title = movieInfo.title || title;
          description = movieInfo.description || description || "No description";
          release_date = movieInfo.release_date || release_date || new Date().toISOString().split('T')[0];
          duration_minutes = movieInfo.duration_minutes || duration_minutes || 120;
          rating = movieInfo.rating || rating || null;
          poster_url = movieInfo.poster_url || poster_url || '';
          // Try to extract trailer URL from TMDB data if available
          if (movieInfo.trailer_url) {
            trailer_url = movieInfo.trailer_url;
          }
          
          logger.info(`Auto-fetched data for movie: ${title}`);
        } catch (fetchError) {
          logger.warn(`Failed to auto-fetch data for movie: ${title}`, fetchError);
          // Continue with user-provided data if auto-fetch fails
        }
      }

      // Check if a movie with the same title already exists (case-insensitive)
      const Movie = require("../models/movieModel");
      const existingMovie = await Movie.existsByTitle(title);
      
      if (existingMovie) {
        return res.status(409).json({
          success: false,
          message: "A movie with this title already exists",
          data: existingMovie
        });
      }

      const db = require("../config/database");
      
      // Start a transaction to ensure data consistency
      const client = await db.pool.connect();
      
      try {
        await client.query('BEGIN');
        
        // Use the enhanced model create method which includes duplicate checking
        const newMovie = await Movie.create({
          title: title,
          description: description || "No description",
          release_date: release_date || new Date().toISOString().split('T')[0],
          duration_minutes: duration_minutes ? parseInt(duration_minutes) : 120,
          rating: rating ? parseFloat(rating) : null,
          poster_url: poster_url || '',
          trailer_url: trailer_url || ''
        });
        
        const movieId = newMovie.movie_id;
        
        // If we have auto-fetched data, also insert related information
        if (auto_fetch) {
          try {
            const movieDataService = require('../services/movieDataService');
            const movieInfo = await movieDataService.getMovieInfo(title);
            
            // Insert genres
            if (movieInfo.genres && movieInfo.genres.length > 0) {
              for (const genreName of movieInfo.genres) {
                // Check if genre exists, if not create it
                let genreResult = await client.query(
                  'SELECT genre_id FROM genres WHERE genre_name = $1',
                  [genreName]
                );
                
                let genreId;
                if (genreResult.rows.length === 0) {
                  // Create new genre
                  const newGenre = await client.query(
                    'INSERT INTO genres (genre_name) VALUES ($1) RETURNING genre_id',
                    [genreName]
                  );
                  genreId = newGenre.rows[0].genre_id;
                } else {
                  genreId = genreResult.rows[0].genre_id;
                }
                
                // Link genre to movie
                await client.query(
                  'INSERT INTO movie_genres (movie_id, genre_id) VALUES ($1, $2)',
                  [movieId, genreId]
                );
              }
            }
            
            // Insert directors
            if (movieInfo.directors && movieInfo.directors.length > 0) {
              for (const directorName of movieInfo.directors) {
                // Split name into first and last name
                const nameParts = directorName.split(' ');
                const firstName = nameParts[0] || directorName;
                const lastName = nameParts.slice(1).join(' ') || 'Unknown';
                
                // Check if director exists, if not create it
                let directorResult = await client.query(
                  'SELECT director_id FROM directors WHERE first_name = $1 AND last_name = $2',
                  [firstName, lastName]
                );
                
                let directorId;
                if (directorResult.rows.length === 0) {
                  // Create new director
                  const newDirector = await client.query(
                    'INSERT INTO directors (first_name, last_name) VALUES ($1, $2) RETURNING director_id',
                    [firstName, lastName]
                  );
                  directorId = newDirector.rows[0].director_id;
                } else {
                  directorId = directorResult.rows[0].director_id;
                }
                
                // Link director to movie
                await client.query(
                  'INSERT INTO movie_directors (movie_id, director_id) VALUES ($1, $2)',
                  [movieId, directorId]
                );
              }
            }
            
            // Insert actors
            if (movieInfo.actors && movieInfo.actors.length > 0) {
              for (const actorName of movieInfo.actors) {
                // Split name into first and last name
                const nameParts = actorName.split(' ');
                const firstName = nameParts[0] || actorName;
                const lastName = nameParts.slice(1).join(' ') || 'Unknown';
                
                // Check if actor exists, if not create it
                let actorResult = await client.query(
                  'SELECT actor_id FROM actors WHERE first_name = $1 AND last_name = $2',
                  [firstName, lastName]
                );
                
                let actorId;
                if (actorResult.rows.length === 0) {
                  // Create new actor
                  const newActor = await client.query(
                    'INSERT INTO actors (first_name, last_name) VALUES ($1, $2) RETURNING actor_id',
                    [firstName, lastName]
                  );
                  actorId = newActor.rows[0].actor_id;
                } else {
                  actorId = actorResult.rows[0].actor_id;
                }
                
                // Link actor to movie
                await client.query(
                  'INSERT INTO movie_actors (movie_id, actor_id) VALUES ($1, $2)',
                  [movieId, actorId]
                );
              }
            }
          } catch (relationError) {
            logger.warn(`Failed to insert related data for movie: ${title}`, relationError);
            // Continue even if related data insertion fails
          }
        }
        
        await client.query('COMMIT');
        
        logger.info(`Movie created successfully: ${movieId}`);

        res.status(201).json({
          success: true,
          message: "Movie created successfully",
          data: newMovie,
        });
      } catch (transactionError) {
        await client.query('ROLLBACK');
        
        // Handle duplicate movie error specifically
        if (transactionError.message.includes('already exists')) {
          return res.status(409).json({
            success: false,
            message: "A movie with this title already exists"
          });
        }
        
        throw transactionError;
      } finally {
        client.release();
      }
    } catch (error) {
      logger.error("Error in createMovie:", error);
      res.status(500).json({
        success: false,
        message: "Error creating movie: " + error.message,
        error: error.message,
      });
    }
  },

  // Update movie - ENHANCED with trailer support
  updateMovie: async (req, res) => {
    try {
      const { id } = req.params;
      const { title, description, release_date, duration_minutes, rating, poster_url, trailer_url } =
        req.body;

      logger.info(`Updating movie: ${id}`);

      const db = require("../config/database");
      const query = `
        UPDATE movies 
        SET title = COALESCE($1, title), 
            description = COALESCE($2, description), 
            release_date = COALESCE($3, release_date), 
            duration_minutes = COALESCE($4, duration_minutes), 
            rating = COALESCE($5, rating),
            poster_url = COALESCE($6, poster_url),
            trailer_url = COALESCE($7, trailer_url),
            updated_at = CURRENT_TIMESTAMP
        WHERE movie_id = $8
        RETURNING *
      `;

      const result = await db.query(query, [
        title,
        description,
        release_date,
        duration_minutes,
        rating,
        poster_url,
        trailer_url,
        id,
      ]);

      if (result.rows.length === 0) {
        logger.warn(`Movie not found for update: ${id}`);
        return res.status(404).json({
          success: false,
          message: "Movie not found",
        });
      }

      logger.info(`Movie updated successfully: ${id}`);

      res.json({
        success: true,
        message: "Movie updated successfully",
        data: result.rows[0],
      });
    } catch (error) {
      logger.error("Error in updateMovie:", error);
      res.status(500).json({
        success: false,
        message: "Error updating movie",
        error: error.message,
      });
    }
  },

  // Delete movie
  deleteMovie: async (req, res) => {
    try {
      const { id } = req.params;
      logger.info(`Deleting movie: ${id}`);
      
      const db = require("../config/database");

      const query = "DELETE FROM movies WHERE movie_id = $1 RETURNING *";
      const result = await db.query(query, [id]);

      if (result.rows.length === 0) {
        logger.warn(`Movie not found for deletion: ${id}`);
        return res.status(404).json({
          success: false,
          message: "Movie not found",
        });
      }

      logger.info(`Movie deleted successfully: ${id}`);

      res.json({
        success: true,
        message: "Movie deleted successfully",
        data: result.rows[0],
      });
    } catch (error) {
      logger.error("Error in deleteMovie:", error);
      res.status(500).json({
        success: false,
        message: "Error deleting movie",
        error: error.message,
      });
    }
  },
};

module.exports = movieController;
