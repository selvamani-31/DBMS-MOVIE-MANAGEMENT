const logger = require('../utils/logger');

const collectionController = {
  // Get all collections for a user
  getUserCollections: async (req, res) => {
    try {
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      const db = require("../config/database");
      
      const query = `
        SELECT 
          c.*,
          COUNT(cm.movie_id) as movie_count
        FROM collections c
        LEFT JOIN collection_movies cm ON c.collection_id = cm.collection_id
        WHERE c.user_id = $1
        GROUP BY c.collection_id
        ORDER BY c.created_at DESC
      `;
      
      const result = await db.query(query, [userId]);
      const collections = result.rows;
      
      res.json({
        success: true,
        data: collections,
      });
    } catch (error) {
      logger.error("Error in getUserCollections:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching collections",
        error: error.message,
      });
    }
  },

  // Create a new collection
  createCollection: async (req, res) => {
    try {
      const { name, description, is_public = false } = req.body;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Validation
      if (!name || name.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Collection name is required",
        });
      }
      
      if (name.trim().length > 100) {
        return res.status(400).json({
          success: false,
          message: "Collection name must be less than 100 characters",
        });
      }
      
      if (description && description.trim().length > 500) {
        return res.status(400).json({
          success: false,
          message: "Description must be less than 500 characters",
        });
      }
      
      const db = require("../config/database");
      
      // Insert the collection
      const query = `
        INSERT INTO collections (user_id, name, description, is_public)
        VALUES ($1, $2, $3, $4)
        RETURNING *
      `;
      
      const result = await db.query(query, [
        userId, 
        name.trim(), 
        description ? description.trim() : null, 
        is_public
      ]);
      const newCollection = result.rows[0];
      
      logger.info(`Collection created: ${newCollection.collection_id} by user ${userId}`);
      
      res.status(201).json({
        success: true,
        message: "Collection created successfully",
        data: newCollection,
      });
    } catch (error) {
      logger.error("Error in createCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error creating collection",
        error: error.message,
      });
    }
  },

  // Get a specific collection with its movies
  getCollection: async (req, res) => {
    try {
      const { collectionId } = req.params;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Log incoming parameters for debugging
      logger.debug('getCollection called with params:', { collectionId, userId });
      
      // Convert collectionId to integer if it's a string
      const collectionIdInt = parseInt(collectionId);
      if (isNaN(collectionIdInt)) {
        logger.warn('Invalid collection ID format received:', { collectionId });
        return res.status(400).json({
          success: false,
          message: "Invalid collection ID format",
        });
      }
      
      logger.debug('Converted collection ID to integer:', { collectionIdInt });
      
      const db = require("../config/database");
      
      // Check if user has access to this collection
      const accessCheck = await db.query(
        `SELECT c.*, u.username as owner_username
         FROM collections c
         JOIN users u ON c.user_id = u.user_id
         WHERE c.collection_id = $1 AND (c.user_id = $2 OR c.is_public = true)`,
        [collectionIdInt, userId]
      );
      
      logger.debug('Access check result:', { rowCount: accessCheck.rows.length });
      
      if (accessCheck.rows.length === 0) {
        logger.warn('Collection not found or access denied:', { collectionIdInt, userId });
        return res.status(404).json({
          success: false,
          message: "Collection not found or you don't have permission to view it",
        });
      }
      
      const collection = accessCheck.rows[0];
      logger.debug('Collection found:', { collectionId: collection.collection_id, name: collection.name });
      
      // Get movies in this collection
      const moviesQuery = `
        SELECT 
          m.*,
          ARRAY_AGG(DISTINCT g.genre_name) as genres,
          COALESCE(AVG(r.rating), 0) as average_rating,
          (SELECT MAX(added_at) FROM collection_movies WHERE movie_id = m.movie_id AND collection_id = $1) as added_at
        FROM movies m
        JOIN collection_movies cm ON m.movie_id = cm.movie_id
        LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
        LEFT JOIN genres g ON mg.genre_id = g.genre_id
        LEFT JOIN reviews r ON m.movie_id = r.movie_id
        WHERE cm.collection_id = $1
        GROUP BY m.movie_id
        ORDER BY (SELECT MAX(added_at) FROM collection_movies WHERE movie_id = m.movie_id AND collection_id = $1) DESC
      `;
      
      logger.debug('Executing movies query with collection ID:', { collectionIdInt });
      const moviesResult = await db.query(moviesQuery, [collectionIdInt]);
      logger.debug('Movies query result:', { movieCount: moviesResult.rows.length });
      
      const movies = moviesResult.rows.map(movie => {
        if (movie.genres && movie.genres.length > 0) {
          movie.genres = movie.genres.filter(g => g !== null);
          if (movie.genres.length === 0) {
            movie.genres = [];
          }
        } else {
          movie.genres = [];
        }
        return movie;
      });
      
      collection.movies = movies;
      
      logger.debug('Returning collection with movies:', { 
        collectionId: collection.collection_id, 
        movieCount: collection.movies.length 
      });
      
      res.json({
        success: true,
        data: collection,
      });
    } catch (error) {
      logger.error("Error in getCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching collection",
        error: error.message,
      });
    }
  },

  // Update a collection
  updateCollection: async (req, res) => {
    try {
      const { collectionId } = req.params;
      const { name, description, is_public } = req.body;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Convert collectionId to integer if it's a string
      const collectionIdInt = parseInt(collectionId);
      if (isNaN(collectionIdInt)) {
        return res.status(400).json({
          success: false,
          message: "Invalid collection ID format",
        });
      }
      
      // Validation
      if (name && name.trim().length === 0) {
        return res.status(400).json({
          success: false,
          message: "Collection name cannot be empty",
        });
      }
      
      if (name && name.trim().length > 100) {
        return res.status(400).json({
          success: false,
          message: "Collection name must be less than 100 characters",
        });
      }
      
      if (description && description.trim().length > 500) {
        return res.status(400).json({
          success: false,
          message: "Description must be less than 500 characters",
        });
      }
      
      const db = require("../config/database");
      
      // Check if collection exists and belongs to user
      const collectionCheck = await db.query(
        'SELECT collection_id FROM collections WHERE collection_id = $1 AND user_id = $2',
        [collectionIdInt, userId]
      );
      
      if (collectionCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collection not found or you don't have permission to edit it",
        });
      }
      
      // Update the collection
      const query = `
        UPDATE collections 
        SET 
          name = COALESCE($1, name),
          description = COALESCE($2, description),
          is_public = COALESCE($3, is_public),
          updated_at = CURRENT_TIMESTAMP
        WHERE collection_id = $4
        RETURNING *
      `;
      
      const result = await db.query(query, [
        name ? name.trim() : null,
        description ? description.trim() : null,
        is_public !== undefined ? is_public : null,
        collectionIdInt
      ]);
      const updatedCollection = result.rows[0];
      
      logger.info(`Collection ${collectionIdInt} updated by user ${userId}`);
      
      res.json({
        success: true,
        message: "Collection updated successfully",
        data: updatedCollection,
      });
    } catch (error) {
      logger.error("Error in updateCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error updating collection",
        error: error.message,
      });
    }
  },

  // Delete a collection
  deleteCollection: async (req, res) => {
    try {
      const { collectionId } = req.params;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Convert collectionId to integer if it's a string
      const collectionIdInt = parseInt(collectionId);
      if (isNaN(collectionIdInt)) {
        return res.status(400).json({
          success: false,
          message: "Invalid collection ID format",
        });
      }
      
      const db = require("../config/database");
      
      // Check if collection exists and belongs to user
      const collectionCheck = await db.query(
        'SELECT collection_id FROM collections WHERE collection_id = $1 AND user_id = $2',
        [collectionIdInt, userId]
      );
      
      if (collectionCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collection not found or you don't have permission to delete it",
        });
      }
      
      // Delete collection movies first (cascade)
      await db.query('DELETE FROM collection_movies WHERE collection_id = $1', [collectionIdInt]);
      
      // Delete the collection
      const query = 'DELETE FROM collections WHERE collection_id = $1 RETURNING *';
      const result = await db.query(query, [collectionIdInt]);
      const deletedCollection = result.rows[0];
      
      logger.info(`Collection ${collectionIdInt} deleted by user ${userId}`);
      
      res.json({
        success: true,
        message: "Collection deleted successfully",
        data: deletedCollection,
      });
    } catch (error) {
      logger.error("Error in deleteCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error deleting collection",
        error: error.message,
      });
    }
  },

  // Add movie to collection
  addMovieToCollection: async (req, res) => {
    try {
      const { collectionId } = req.params;
      const { movieId } = req.body;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Validation
      if (!movieId) {
        return res.status(400).json({
          success: false,
          message: "Movie ID is required",
        });
      }
      
      // Convert collectionId to integer if it's a string
      const collectionIdInt = parseInt(collectionId);
      if (isNaN(collectionIdInt)) {
        return res.status(400).json({
          success: false,
          message: "Invalid collection ID format",
        });
      }
      
      const db = require("../config/database");
      
      // Check if collection exists and belongs to user
      const collectionCheck = await db.query(
        'SELECT collection_id FROM collections WHERE collection_id = $1 AND user_id = $2',
        [collectionIdInt, userId]
      );
      
      if (collectionCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collection not found or you don't have permission to modify it",
        });
      }
      
      // Check if movie exists
      const movieCheck = await db.query(
        'SELECT movie_id FROM movies WHERE movie_id = $1',
        [movieId]
      );
      
      if (movieCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Movie not found",
        });
      }
      
      // Check if movie is already in collection
      const existingCheck = await db.query(
        'SELECT collection_movie_id FROM collection_movies WHERE collection_id = $1 AND movie_id = $2',
        [collectionIdInt, movieId]
      );
      
      if (existingCheck.rows.length > 0) {
        return res.status(400).json({
          success: false,
          message: "Movie is already in this collection",
        });
      }
      
      // Add movie to collection
      const query = `
        INSERT INTO collection_movies (collection_id, movie_id)
        VALUES ($1, $2)
        RETURNING *
      `;
      
      const result = await db.query(query, [collectionIdInt, movieId]);
      const addedMovie = result.rows[0];
      
      logger.info(`Movie ${movieId} added to collection ${collectionIdInt} by user ${userId}`);
      
      res.status(201).json({
        success: true,
        message: "Movie added to collection successfully",
        data: addedMovie,
      });
    } catch (error) {
      logger.error("Error in addMovieToCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error adding movie to collection",
        error: error.message,
      });
    }
  },

  // Remove movie from collection
  removeMovieFromCollection: async (req, res) => {
    try {
      const { collectionId, movieId } = req.params;
      const userId = req.user.userId; // From auth middleware (camelCase)
      
      // Convert collectionId to integer if it's a string
      const collectionIdInt = parseInt(collectionId);
      if (isNaN(collectionIdInt)) {
        return res.status(400).json({
          success: false,
          message: "Invalid collection ID format",
        });
      }
      
      const db = require("../config/database");
      
      // Check if collection exists and belongs to user
      const collectionCheck = await db.query(
        'SELECT collection_id FROM collections WHERE collection_id = $1 AND user_id = $2',
        [collectionIdInt, userId]
      );
      
      if (collectionCheck.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Collection not found or you don't have permission to modify it",
        });
      }
      
      // Remove movie from collection
      const query = `
        DELETE FROM collection_movies 
        WHERE collection_id = $1 AND movie_id = $2
        RETURNING *
      `;
      
      const result = await db.query(query, [collectionIdInt, movieId]);
      
      if (result.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Movie not found in this collection",
        });
      }
      
      const removedMovie = result.rows[0];
      
      logger.info(`Movie ${movieId} removed from collection ${collectionIdInt} by user ${userId}`);
      
      res.json({
        success: true,
        message: "Movie removed from collection successfully",
        data: removedMovie,
      });
    } catch (error) {
      logger.error("Error in removeMovieFromCollection:", error);
      res.status(500).json({
        success: false,
        message: "Error removing movie from collection",
        error: error.message,
      });
    }
  },

  // Get public collections
  getPublicCollections: async (req, res) => {
    try {
      const { page = 1, limit = 20 } = req.query;
      const offset = (parseInt(page) - 1) * parseInt(limit);
      
      const db = require("../config/database");
      
      const query = `
        SELECT 
          c.*,
          u.username as owner_username,
          COUNT(cm.movie_id) as movie_count
        FROM collections c
        JOIN users u ON c.user_id = u.user_id
        LEFT JOIN collection_movies cm ON c.collection_id = cm.collection_id
        WHERE c.is_public = true
        GROUP BY c.collection_id, u.username
        ORDER BY c.created_at DESC
        LIMIT $1 OFFSET $2
      `;
      
      const result = await db.query(query, [parseInt(limit), offset]);
      const collections = result.rows;
      
      res.json({
        success: true,
        data: collections,
        pagination: {
          page: parseInt(page),
          limit: parseInt(limit),
          count: collections.length
        }
      });
    } catch (error) {
      logger.error("Error in getPublicCollections:", error);
      res.status(500).json({
        success: false,
        message: "Error fetching public collections",
        error: error.message,
      });
    }
  },
};

module.exports = collectionController;