const validateMovie = (req, res, next) => {
  const { title, description, release_date, duration_minutes } = req.body;

  if (!title || title.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Title is required'
    });
  }

  if (!description || description.trim() === '') {
    return res.status(400).json({
      success: false,
      message: 'Description is required'
    });
  }

  if (!release_date) {
    return res.status(400).json({
      success: false,
      message: 'Release date is required'
    });
  }

  if (!duration_minutes || duration_minutes <= 0) {
    return res.status(400).json({
      success: false,
      message: 'Valid duration is required'
    });
  }

  next();
};

module.exports = {
  validateMovie
};