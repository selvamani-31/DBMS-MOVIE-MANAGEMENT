/**
 * Utility functions for handling encoding issues in movie data
 */

// Extended list of characters that cause issues when converting from UTF-8 to WIN1252
const problematicChars = [
  '\u200b', // Zero-width space
  '\u200c', // Zero-width non-joiner
  '\u200d', // Zero-width joiner
  '\u200e', // Left-to-right mark
  '\u200f', // Right-to-left mark
  '\u202a', // Left-to-right embedding
  '\u202b', // Right-to-left embedding
  '\u202c', // Pop directional formatting
  '\u202d', // Left-to-right override
  '\u202e', // Right-to-left override
  '\u0142', // Latin small letter l with stroke (ł) - 0xc5 0x82
  '\u0141', // Latin capital letter l with stroke (Ł)
  '\u0107', // Latin small letter c with acute (ć)
  '\u0106', // Latin capital letter c with acute (Ć)
  '\u0119', // Latin small letter e with ogonek (ę)
  '\u0118', // Latin capital letter e with ogonek (Ę)
  '\u015b', // Latin small letter s with acute (ś)
  '\u015a', // Latin capital letter s with acute (Ś)
  '\u017c', // Latin small letter z with dot above (ż)
  '\u017b', // Latin capital letter z with dot above (Ż)
  '\u017a', // Latin small letter z with acute (ź)
  '\u0179', // Latin capital letter z with acute (Ź)
  '\u0144', // Latin small letter n with acute (ń)
  '\u0143', // Latin capital letter n with acute (Ń)
  '\u00f3', // Latin small letter o with acute (ó)
  '\u00d3', // Latin capital letter o with acute (Ó)
  '\u0105', // Latin small letter a with ogonek (ą)
  '\u0104', // Latin capital letter a with ogonek (Ą)
  '\u014d', // Latin small letter o with macron (ō) - 0xc5 0x8d
  '\u014c', // Latin capital letter o with macron (Ō)
  '\u2013', // En dash
  '\u2014', // Em dash
  '\u201c', // Left double quotation mark
  '\u201d', // Right double quotation mark
  '\u2018', // Left single quotation mark
  '\u2019', // Right single quotation mark
  '\u2026', // Horizontal ellipsis
  '\u00ab', // Left-pointing double angle quotation mark
  '\u00bb', // Right-pointing double angle quotation mark
];

// Create regex pattern for all problematic characters
const problematicCharsRegex = new RegExp(`[${problematicChars.join('')}]`, 'g');

/**
 * Clean string data by removing problematic Unicode characters
 * @param {string} str - The string to clean
 * @returns {string} - The cleaned string
 */
function cleanString(str) {
  if (typeof str !== 'string') {
    return str;
  }
  
  return str.replace(problematicCharsRegex, '');
}

/**
 * Clean movie data by removing problematic Unicode characters from all text fields
 * @param {Object} movieData - The movie data object
 * @returns {Object} - The cleaned movie data object
 */
function cleanMovieData(movieData) {
  const cleanedData = { ...movieData };
  
  // Clean common movie text fields
  const textFields = ['title', 'description', 'poster_url', 'trailer_url'];
  
  textFields.forEach(field => {
    if (cleanedData[field]) {
      cleanedData[field] = cleanString(cleanedData[field]);
    }
  });
  
  return cleanedData;
}

/**
 * Clean person data (actors, directors) by removing problematic Unicode characters
 * @param {Object} personData - The person data object
 * @returns {Object} - The cleaned person data object
 */
function cleanPersonData(personData) {
  const cleanedData = { ...personData };
  
  // Clean common person text fields
  const textFields = ['first_name', 'last_name'];
  
  textFields.forEach(field => {
    if (cleanedData[field]) {
      cleanedData[field] = cleanString(cleanedData[field]);
    }
  });
  
  return cleanedData;
}

/**
 * Check if a string contains problematic Unicode characters
 * @param {string} str - The string to check
 * @returns {boolean} - True if problematic characters are found
 */
function hasProblematicChars(str) {
  if (typeof str !== 'string') {
    return false;
  }
  
  return problematicCharsRegex.test(str);
}

module.exports = {
  cleanString,
  cleanMovieData,
  cleanPersonData,
  hasProblematicChars
};