const Joi = require('joi');

// Movie validation schemas
const movieSchemas = {
  create: Joi.object({
    title: Joi.string().trim().min(1).max(200).required(),
    description: Joi.string().trim().max(2000).allow('').optional(),
    release_date: Joi.date().max('now').optional(),
    duration_minutes: Joi.number().integer().min(1).max(600).optional(),
    rating: Joi.number().min(0).max(10).allow(null).optional(),
    poster_url: Joi.string().uri().allow('').optional(),
    trailer_url: Joi.string().uri().allow('').optional(),
    auto_fetch: Joi.boolean().optional().default(false)
  }),

  update: Joi.object({
    title: Joi.string().trim().min(1).max(200),
    description: Joi.string().trim().max(2000).allow(''),
    release_date: Joi.date().max('now'),
    duration_minutes: Joi.number().integer().min(1).max(600),
    rating: Joi.number().min(0).max(10).allow(null),
    poster_url: Joi.string().uri().allow(''),
    trailer_url: Joi.string().uri().allow('')
  }).min(1)
};

// User validation schemas
const userSchemas = {
  register: Joi.object({
    username: Joi.string().trim().alphanum().min(3).max(30).required(),
    email: Joi.string().trim().email().required(),
    password: Joi.string().min(6).max(100).required(),
    first_name: Joi.string().trim().max(50).allow('').default(''),
    last_name: Joi.string().trim().max(50).allow('').default('')
  }),

  login: Joi.object({
    email: Joi.string().trim().email().required(),
    password: Joi.string().required()
  })
};

// Query parameter schemas
const querySchemas = {
  pagination: Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(20),
    search: Joi.string().trim().max(100).allow('').default('')
  })
};

// Validation middleware factory
const validate = (schema, property = 'body') => {
  return (req, res, next) => {
    // If auto_fetch is enabled, make most fields optional and allow empty strings
    let validationSchema = schema;
    if (req[property] && req[property].auto_fetch) {
      // Create a modified schema with optional fields for auto-fetch mode
      // Allow empty strings and null values for optional fields
      validationSchema = Joi.object({
        title: Joi.string().trim().min(1).max(200).required(),
        description: Joi.string().trim().max(2000).allow('', null).optional(),
        release_date: Joi.date().max('now').allow('', null).optional(),
        duration_minutes: Joi.number().integer().min(1).max(600).allow('', null).optional(),
        rating: Joi.number().min(0).max(10).allow('', null).optional(),
        poster_url: Joi.string().uri().allow('', null).optional(),
        trailer_url: Joi.string().uri().allow('', null).optional(),
        auto_fetch: Joi.boolean().optional().default(false)
      });
    }

    const { error, value } = validationSchema.validate(req[property], { 
      abortEarly: false,
      stripUnknown: true 
    });

    if (error) {
      const errors = error.details.map(detail => ({
        field: detail.path.join('.'),
        message: detail.message
      }));

      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors
      });
    }

    // Replace request data with validated data
    req[property] = value;
    next();
  };
};

module.exports = {
  movieSchemas,
  userSchemas,
  querySchemas,
  validate
};