const db = require("../config/database");

const User = {
  // Find user by email
  findByEmail: async (email) => {
    const query = "SELECT * FROM users WHERE email = $1";
    const result = await db.query(query, [email]);
    return result.rows[0];
  },

  // Find user by ID
  findById: async (id) => {
    const query =
      "SELECT user_id, username, email, first_name, last_name, role, created_at FROM users WHERE user_id = $1";
    const result = await db.query(query, [id]);
    return result.rows[0];
  },

  // Create new user
  create: async (userData) => {
    const { username, email, password_hash, first_name, last_name } = userData;
    const query = `
      INSERT INTO users (username, email, password_hash, first_name, last_name)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING user_id, username, email, first_name, last_name, role, created_at
    `;

    const result = await db.query(query, [
      username,
      email,
      password_hash,
      first_name,
      last_name,
    ]);
    return result.rows[0];
  },
};

module.exports = User;
