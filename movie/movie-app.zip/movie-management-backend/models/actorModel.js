const db = require("../config/database");
const { cleanPersonData } = require("../utils/encodingUtils");

const Actor = {
  // Get all actors
  getAll: async () => {
    const query = "SELECT * FROM actors ORDER BY first_name, last_name";
    const result = await db.query(query);
    return result.rows;
  },

  // Get actor by ID
  getById: async (id) => {
    const query = "SELECT * FROM actors WHERE actor_id = $1";
    const result = await db.query(query, [id]);
    return result.rows[0];
  },

  // Create new actor
  create: async (actorData) => {
    // Clean the actor data to prevent encoding issues
    const cleanedData = cleanPersonData(actorData);
    
    const { first_name, last_name } = cleanedData;
    const query = `
      INSERT INTO actors (first_name, last_name)
      VALUES ($1, $2)
      RETURNING *
    `;

    const result = await db.query(query, [first_name, last_name]);
    return result.rows[0];
  },

  // Update actor
  update: async (id, actorData) => {
    // Clean the actor data to prevent encoding issues
    const cleanedData = cleanPersonData(actorData);
    
    const { first_name, last_name } = cleanedData;
    const query = `
      UPDATE actors 
      SET first_name = $1, last_name = $2, updated_at = CURRENT_TIMESTAMP
      WHERE actor_id = $3
      RETURNING *
    `;

    const result = await db.query(query, [first_name, last_name, id]);
    return result.rows[0];
  },

  // Delete actor
  delete: async (id) => {
    const query = "DELETE FROM actors WHERE actor_id = $1 RETURNING *";
    const result = await db.query(query, [id]);
    return result.rows[0];
  }
};

module.exports = Actor;