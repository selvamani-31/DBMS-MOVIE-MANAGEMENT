const db = require("../config/database");
const { cleanMovieData } = require("../utils/encodingUtils");

const Movie = {
  // Get all movies with pagination
  getAll: async (page = 1, limit = 10, search = "") => {
    const offset = (page - 1) * limit;
    let query = `
      SELECT 
        m.*,
        ARRAY_AGG(DISTINCT g.genre_name) as genres,
        ARRAY_AGG(DISTINCT CONCAT(a.first_name, ' ', a.last_name)) as actors,
        ARRAY_AGG(DISTINCT CONCAT(d.first_name, ' ', d.last_name)) as directors,
        COALESCE(AVG(r.rating), 0) as average_rating,
        COUNT(r.review_id) as review_count
      FROM movies m
      LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
      LEFT JOIN genres g ON mg.genre_id = g.genre_id
      LEFT JOIN movie_actors ma ON m.movie_id = ma.movie_id
      LEFT JOIN actors a ON ma.actor_id = a.actor_id
      LEFT JOIN movie_directors md ON m.movie_id = md.movie_id
      LEFT JOIN directors d ON md.director_id = d.director_id
      LEFT JOIN reviews r ON m.movie_id = r.movie_id
    `;

    const values = [];

    if (search) {
      query += ` WHERE m.title ILIKE $1 OR m.description ILIKE $1`;
      values.push(`%${search}%`);
    }

    query += `
      GROUP BY m.movie_id
      ORDER BY m.created_at DESC
      LIMIT $${values.length + 1} OFFSET $${values.length + 2}
    `;

    values.push(limit, offset);

    const result = await db.query(query, values);
    return result.rows;
  },

  // Get movie by ID
  getById: async (id) => {
    const query = `
      SELECT 
        m.*,
        ARRAY_AGG(DISTINCT g.genre_name) as genres,
        ARRAY_AGG(DISTINCT json_build_object(
          'actor_id', a.actor_id,
          'name', CONCAT(a.first_name, ' ', a.last_name),
          'character', ma.character_name
        )) as actors,
        ARRAY_AGG(DISTINCT json_build_object(
          'director_id', d.director_id,
          'name', CONCAT(d.first_name, ' ', d.last_name)
        )) as directors
      FROM movies m
      LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
      LEFT JOIN genres g ON mg.genre_id = g.genre_id
      LEFT JOIN movie_actors ma ON m.movie_id = ma.movie_id
      LEFT JOIN actors a ON ma.actor_id = a.actor_id
      LEFT JOIN movie_directors md ON m.movie_id = md.movie_id
      LEFT JOIN directors d ON md.director_id = d.director_id
      WHERE m.movie_id = $1
      GROUP BY m.movie_id
    `;

    const result = await db.query(query, [id]);
    return result.rows[0];
  },

  // Check if a movie with the same title already exists (more robust version)
  existsByTitle: async (title) => {
    // Normalize the title for comparison
    const normalizedTitle = title.trim();
    
    const query = `
      SELECT movie_id, title FROM movies 
      WHERE LOWER(TRIM(title)) = LOWER($1)
    `;
    
    const result = await db.query(query, [normalizedTitle]);
    return result.rows[0]; // Returns the movie if found, undefined if not
  },

  // Create new movie with built-in duplicate checking and constraint handling
  create: async (movieData) => {
    // Clean the movie data to prevent encoding issues
    const cleanedData = cleanMovieData(movieData);
    
    const {
      title,
      description,
      release_date,
      duration_minutes,
      rating,
      poster_url,
      trailer_url,
    } = cleanedData;
    
    // First check if a movie with this title already exists (application-level check)
    const existingMovie = await Movie.existsByTitle(title);
    if (existingMovie) {
      throw new Error('A movie with this title already exists');
    }
    
    // If no duplicate, proceed with creation
    const query = `
      INSERT INTO movies (title, description, release_date, duration_minutes, rating, poster_url, trailer_url)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      RETURNING *
    `;

    try {
      const result = await db.query(query, [
        title.trim(), // Also normalize on insert
        description,
        release_date,
        duration_minutes,
        rating,
        poster_url,
        trailer_url,
      ]);
      return result.rows[0];
    } catch (error) {
      // Handle database constraint violation
      if (error.message.includes('unique constraint') || error.message.includes('duplicate key')) {
        throw new Error('A movie with this title already exists');
      }
      throw error; // Re-throw other errors
    }
  },

  // Update movie
  update: async (id, movieData) => {
    // Clean the movie data to prevent encoding issues
    const cleanedData = cleanMovieData(movieData);
    
    const {
      title,
      description,
      release_date,
      duration_minutes,
      rating,
      poster_url,
      trailer_url,
    } = cleanedData;
    
    const query = `
      UPDATE movies 
      SET title = $1, description = $2, release_date = $3, duration_minutes = $4, 
          rating = $5, poster_url = $6, trailer_url = $7, updated_at = CURRENT_TIMESTAMP
      WHERE movie_id = $8
      RETURNING *
    `;

    const result = await db.query(query, [
      title,
      description,
      release_date,
      duration_minutes,
      rating,
      poster_url,
      trailer_url,
      id,
    ]);
    return result.rows[0];
  },

  // Delete movie
  delete: async (id) => {
    const query = "DELETE FROM movies WHERE movie_id = $1 RETURNING *";
    const result = await db.query(query, [id]);
    return result.rows[0];
  },

  // Advanced search with filters
  searchWithFilters: async (filters) => {
    const {
      search = "",
      genres = [],
      minRating = 0,
      maxRating = 10,
      yearFrom,
      yearTo,
      page = 1,
      limit = 10,
    } = filters;

    const offset = (page - 1) * limit;
    let query = `
      SELECT 
        m.*,
        ARRAY_AGG(DISTINCT g.genre_name) as genres,
        COALESCE(AVG(r.rating), 0) as average_rating
      FROM movies m
      LEFT JOIN movie_genres mg ON m.movie_id = mg.movie_id
      LEFT JOIN genres g ON mg.genre_id = g.genre_id
      LEFT JOIN reviews r ON m.movie_id = r.movie_id
      WHERE 1=1
    `;

    const values = [];
    let paramCount = 0;

    if (search) {
      paramCount++;
      query += ` AND (m.title ILIKE $${paramCount} OR m.description ILIKE $${paramCount})`;
      values.push(`%${search}%`);
    }

    if (genres.length > 0) {
      paramCount++;
      query += ` AND g.genre_name = ANY($${paramCount})`;
      values.push(genres);
    }

    if (minRating > 0) {
      paramCount++;
      query += ` AND (SELECT COALESCE(AVG(rating), 0) FROM reviews WHERE movie_id = m.movie_id) >= $${paramCount}`;
      values.push(minRating);
    }

    if (yearFrom) {
      paramCount++;
      query += ` AND EXTRACT(YEAR FROM m.release_date) >= $${paramCount}`;
      values.push(yearFrom);
    }

    if (yearTo) {
      paramCount++;
      query += ` AND EXTRACT(YEAR FROM m.release_date) <= $${paramCount}`;
      values.push(yearTo);
    }

    query += `
      GROUP BY m.movie_id
      HAVING COALESCE(AVG(r.rating), 0) BETWEEN $${paramCount + 1} AND $${paramCount + 2}
      ORDER BY average_rating DESC
      LIMIT $${paramCount + 3} OFFSET $${paramCount + 4}
    `;

    values.push(minRating, maxRating, limit, offset);

    const result = await db.query(query, values);
    return result.rows;
  }
};

module.exports = Movie;