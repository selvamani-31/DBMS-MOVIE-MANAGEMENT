const db = require("../config/database");
const { cleanPersonData } = require("../utils/encodingUtils");

const Director = {
  // Get all directors
  getAll: async () => {
    const query = "SELECT * FROM directors ORDER BY first_name, last_name";
    const result = await db.query(query);
    return result.rows;
  },

  // Get director by ID
  getById: async (id) => {
    const query = "SELECT * FROM directors WHERE director_id = $1";
    const result = await db.query(query, [id]);
    return result.rows[0];
  },

  // Create new director
  create: async (directorData) => {
    // Clean the director data to prevent encoding issues
    const cleanedData = cleanPersonData(directorData);
    
    const { first_name, last_name } = cleanedData;
    const query = `
      INSERT INTO directors (first_name, last_name)
      VALUES ($1, $2)
      RETURNING *
    `;

    const result = await db.query(query, [first_name, last_name]);
    return result.rows[0];
  },

  // Update director
  update: async (id, directorData) => {
    // Clean the director data to prevent encoding issues
    const cleanedData = cleanPersonData(directorData);
    
    const { first_name, last_name } = cleanedData;
    const query = `
      UPDATE directors 
      SET first_name = $1, last_name = $2, updated_at = CURRENT_TIMESTAMP
      WHERE director_id = $3
      RETURNING *
    `;

    const result = await db.query(query, [first_name, last_name, id]);
    return result.rows[0];
  },

  // Delete director
  delete: async (id) => {
    const query = "DELETE FROM directors WHERE director_id = $1 RETURNING *";
    const result = await db.query(query, [id]);
    return result.rows[0];
  }
};

module.exports = Director;