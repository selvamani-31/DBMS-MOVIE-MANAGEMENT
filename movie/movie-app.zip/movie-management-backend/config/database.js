const { Pool } = require("pg");
const path = require("path");
require("dotenv").config({ path: path.resolve(__dirname, "../.env") });

// Debug logging to see what env vars are loaded
console.log('[dotenv] DB Configuration:');
console.log('  DB_USER:', process.env.DB_USER || "postgres");
console.log('  DB_HOST:', process.env.DB_HOST || "localhost");
console.log('  DB_NAME:', process.env.DB_NAME || "movie_management");
console.log('  DB_PASSWORD:', process.env.DB_PASSWORD || "password");
console.log('  DB_PORT:', process.env.DB_PORT || 5432);

const pool = new Pool({
  user: process.env.DB_USER || "postgres",
  host: process.env.DB_HOST || "localhost",
  database: process.env.DB_NAME || "movie_management",
  password: process.env.DB_PASSWORD || "password",
  port: process.env.DB_PORT || 5432,
});

// Test database connection asynchronously without blocking
setImmediate(async () => {
  try {
    const client = await pool.connect();
    console.log('✅ Database connected successfully');
    client.release();
  } catch (err) {
    console.error('❌ Database connection failed:', err.message);
    console.warn('⚠️  Server will run but database operations will fail');
    console.warn('To fix: 1) Start PostgreSQL, 2) Create database: CREATE DATABASE movie_management;');
  }
});

// Handle pool errors
pool.on('error', (err) => {
  console.error('Unexpected database error:', err.message);
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool,
};