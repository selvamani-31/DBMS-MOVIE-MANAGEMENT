const express = require("express");
const router = express.Router();
const statsController = require("../controllers/statsController");
const { authenticate } = require("../middleware/auth");

// Public routes
router.get("/", statsController.getStats);
router.get("/activity", statsController.getRecentActivity);

// Protected routes
router.get("/user", authenticate, statsController.getUserStats);

module.exports = router;