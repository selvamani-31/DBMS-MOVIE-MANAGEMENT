const express = require("express");
const router = express.Router();
const { authenticate } = require("../middleware/auth");

// Get current user profile
router.get("/profile", authenticate, async (req, res) => {
  try {
    const User = require("../models/userModel");
    const user = await User.findById(req.user.userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    res.json({
      success: true,
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching user profile",
      error: error.message,
    });
  }
});

module.exports = router;
