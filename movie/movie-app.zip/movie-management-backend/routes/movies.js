const express = require("express");
const router = express.Router();
const movieController = require("../controllers/movieController");
const { authenticate } = require("../middleware/auth");
const { validate, movieSchemas } = require("../utils/validators");

// Public routes
router.get("/", movieController.getAllMovies);
router.get("/:id", movieController.getMovieById);
router.get("/:id/related", movieController.getRelatedMovies);

// Protected routes (for now, just authenticated users can modify)
router.post("/", authenticate, validate(movieSchemas.create), movieController.createMovie);
router.put("/:id", authenticate, validate(movieSchemas.update), movieController.updateMovie);
router.delete("/:id", authenticate, movieController.deleteMovie);

module.exports = router;
