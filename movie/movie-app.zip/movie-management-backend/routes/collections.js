const express = require("express");
const router = express.Router();
const collectionController = require("../controllers/collectionController");
const { authenticate } = require("../middleware/auth");

// Public routes
router.get("/public", collectionController.getPublicCollections);

// Protected routes
router.get("/", authenticate, collectionController.getUserCollections);
router.post("/", authenticate, collectionController.createCollection);
router.get("/:collectionId", authenticate, collectionController.getCollection);
router.put("/:collectionId", authenticate, collectionController.updateCollection);
router.delete("/:collectionId", authenticate, collectionController.deleteCollection);
router.post("/:collectionId/movies", authenticate, collectionController.addMovieToCollection);
router.delete("/:collectionId/movies/:movieId", authenticate, collectionController.removeMovieFromCollection);

module.exports = router;