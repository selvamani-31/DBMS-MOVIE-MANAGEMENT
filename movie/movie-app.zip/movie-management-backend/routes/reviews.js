const express = require("express");
const router = express.Router();
const reviewController = require("../controllers/reviewController");
const { authenticate } = require("../middleware/auth");

// Public routes
router.get("/movie/:movieId", reviewController.getMovieReviews);
router.get("/movie/:movieId/user", authenticate, reviewController.getUserReview);

// Protected routes
router.post("/movie/:movieId", authenticate, reviewController.addReview);
router.put("/:reviewId", authenticate, reviewController.updateReview);
router.delete("/:reviewId", authenticate, reviewController.deleteReview);

module.exports = router;