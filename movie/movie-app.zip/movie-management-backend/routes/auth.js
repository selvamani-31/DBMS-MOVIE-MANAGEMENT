const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");
const { authenticate } = require("../middleware/auth");
const { validate, userSchemas } = require("../utils/validators");

// Auth routes
router.post("/register", validate(userSchemas.register), authController.register);
router.post("/login", validate(userSchemas.login), authController.login);
router.post("/refresh", authenticate, authController.refreshToken);

module.exports = router;