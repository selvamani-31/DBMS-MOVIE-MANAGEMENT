const fs = require('fs');
const path = require('path');
const db = require('./config/database');

async function seedDatabase() {
  try {
    console.log('Seeding database with initial data...');
    
    // Read and execute the functions and triggers
    console.log('Applying database functions and triggers...');
    const sqlFilePath = path.join(__dirname, 'database-functions-triggers.sql');
    const sqlContent = fs.readFileSync(sqlFilePath, 'utf8');
    
    const statements = sqlContent
      .split(';')
      .map(stmt => stmt.trim())
      .filter(stmt => stmt.length > 0);
    
    for (const statement of statements) {
      if (statement.trim()) {
        await db.query(statement);
      }
    }
    
    console.log('✅ Database functions and triggers applied');
    
    // Clear existing data
    await db.query("DELETE FROM reviews");
    await db.query("DELETE FROM watchlist");
    await db.query("DELETE FROM movie_directors");
    await db.query("DELETE FROM movie_actors");
    await db.query("DELETE FROM movie_genres");
    await db.query("DELETE FROM directors");
    await db.query("DELETE FROM actors");
    await db.query("DELETE FROM genres");
    await db.query("DELETE FROM movies");
    await db.query("DELETE FROM users");

    // Insert sample genres
    const genres = [
      { name: "Drama" },
      { name: "Crime" },
      { name: "Action" },
      { name: "Thriller" },
      { name: "Sci-Fi" },
      { name: "Adventure" },
      { name: "Fantasy" },
      { name: "Comedy" },
      { name: "Romance" },
      { name: "Biography" }
    ];

    const genreIds = [];
    for (const genre of genres) {
      const result = await db.query(
        "INSERT INTO genres (genre_name) VALUES ($1) RETURNING genre_id",
        [genre.name]
      );
      genreIds.push(result.rows[0].genre_id);
      console.log(`Added genre: ${genre.name}`);
    }

    // Insert sample actors
    const actors = [
      { first_name: "Tim", last_name: "Robbins" },
      { first_name: "Morgan", last_name: "Freeman" },
      { first_name: "Marlon", last_name: "Brando" },
      { first_name: "Al", last_name: "Pacino" },
      { first_name: "Christian", last_name: "Bale" },
      { first_name: "Heath", last_name: "Ledger" },
      { first_name: "John", last_name: "Travolta" },
      { first_name: "Samuel", last_name: "L. Jackson" },
      { first_name: "Leonardo", last_name: "DiCaprio" },
      { first_name: "Tom", last_name: "Hanks" },
      { first_name: "Keanu", last_name: "Reeves" },
      { first_name: "Laurence", last_name: "Fishburne" }
    ];

    const actorIds = [];
    for (const actor of actors) {
      // Clean the actor data to prevent encoding issues
      const cleanedActor = cleanPersonData(actor);
      
      const result = await db.query(
        "INSERT INTO actors (first_name, last_name) VALUES ($1, $2) RETURNING actor_id",
        [cleanedActor.first_name, cleanedActor.last_name]
      );
      actorIds.push(result.rows[0].actor_id);
      console.log(`Added actor: ${cleanedActor.first_name} ${cleanedActor.last_name}`);
    }

    // Insert sample directors
    const directors = [
      { first_name: "Frank", last_name: "Darabont" },
      { first_name: "Francis", last_name: "Ford Coppola" },
      { first_name: "Christopher", last_name: "Nolan" },
      { first_name: "Quentin", last_name: "Tarantino" },
      { first_name: "Robert", last_name: "Zemeckis" },
      { first_name: "Lana", last_name: "Wachowski" },
      { first_name: "Lilly", last_name: "Wachowski" }
    ];

    const directorIds = [];
    for (const director of directors) {
      // Clean the director data to prevent encoding issues
      const cleanedDirector = cleanPersonData(director);
      
      const result = await db.query(
        "INSERT INTO directors (first_name, last_name) VALUES ($1, $2) RETURNING director_id",
        [cleanedDirector.first_name, cleanedDirector.last_name]
      );
      directorIds.push(result.rows[0].director_id);
      console.log(`Added director: ${cleanedDirector.first_name} ${cleanedDirector.last_name}`);
    }

    // Insert sample movies with poster URLs
    const sampleMovies = [
      {
        title: "The Shawshank Redemption",
        description:
          "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
        release_date: "1994-09-23",
        duration_minutes: 142,
        rating: 9.3,
        poster_url: "https://m.media-amazon.com/images/M/MV5BNDE3ODcxYzMtY2YzZC00NmNlLWJiNDMtZDViZWM2MzIxZDYwXkEyXkFqcGdeQXVyNjAwNDUxODI@._V1_.jpg",
        genres: [genreIds[0], genreIds[1]], // Drama, Crime
        actors: [actorIds[0], actorIds[1]], // Tim Robbins, Morgan Freeman
        directors: [directorIds[0]] // Frank Darabont
      },
      {
        title: "The Godfather",
        description:
          "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.",
        release_date: "1972-03-24",
        duration_minutes: 175,
        rating: 9.2,
        poster_url: "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJiNDMtZDViZWM2MzIxZDYwXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg",
        genres: [genreIds[0], genreIds[1]], // Drama, Crime
        actors: [actorIds[2], actorIds[3]], // Marlon Brando, Al Pacino
        directors: [directorIds[1]] // Francis Ford Coppola
      },
      {
        title: "The Dark Knight",
        description:
          "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
        release_date: "2008-07-18",
        duration_minutes: 152,
        rating: 9.0,
        poster_url: "https://m.media-amazon.com/images/M/MV5BMTMxNTMwODM0NF5BMl5BanBnXkFtZTcwODAyMTk2Mw@@._V1_.jpg",
        genres: [genreIds[2], genreIds[3]], // Action, Thriller
        actors: [actorIds[4], actorIds[5]], // Christian Bale, Heath Ledger
        directors: [directorIds[2]] // Christopher Nolan
      },
      {
        title: "Pulp Fiction",
        description:
          "The lives of two mob hitmen, a boxer, a gangster and his wife, and a pair of diner bandits intertwine in four tales of violence and redemption.",
        release_date: "1994-10-14",
        duration_minutes: 154,
        rating: 8.9,
        poster_url: "https://m.media-amazon.com/images/M/MV5BNGNhMDIzZTUtNTBlZi00MTRlLWFjM2ItYzViMjE3YzI5MjljXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_.jpg",
        genres: [genreIds[1], genreIds[3]], // Crime, Thriller
        actors: [actorIds[6], actorIds[7]], // John Travolta, Samuel L. Jackson
        directors: [directorIds[3]] // Quentin Tarantino
      },
      {
        title: "Forrest Gump",
        description:
          "The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man.",
        release_date: "1994-07-06",
        duration_minutes: 142,
        rating: 8.8,
        poster_url: "https://m.media-amazon.com/images/M/MV5BNWIwODRlZTUtY2U3ZS00Yzg1LWJhNzYtMmZiYmEyNmU1NjMzXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_.jpg",
        genres: [genreIds[0], genreIds[9]], // Drama, Biography
        actors: [actorIds[8]], // Tom Hanks
        directors: [directorIds[4]] // Robert Zemeckis
      },
      {
        title: "Inception",
        description:
          "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
        release_date: "2010-07-16",
        duration_minutes: 148,
        rating: 8.8,
        poster_url: "https://m.media-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_.jpg",
        genres: [genreIds[4], genreIds[5]], // Sci-Fi, Adventure
        actors: [actorIds[8]], // Leonardo DiCaprio
        directors: [directorIds[2]] // Christopher Nolan
      },
      {
        title: "The Matrix",
        description:
          "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.",
        release_date: "1999-03-31",
        duration_minutes: 136,
        rating: 8.7,
        poster_url: "https://m.media-amazon.com/images/M/MV5BNzQzOTk3OTAtNDQ0Zi00ZTVkLWI0MTEtMDllZjNkYzNjNTc4L2ltYWdlXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_.jpg",
        genres: [genreIds[4], genreIds[6]], // Sci-Fi, Fantasy
        actors: [actorIds[9], actorIds[10], actorIds[11]], // Keanu Reeves, Laurence Fishburne
        directors: [directorIds[5], directorIds[6]] // Lana & Lilly Wachowski
      },
      {
        title: "Goodfellas",
        description:
          "The story of Henry Hill and his life in the mob, covering his relationship with his wife Karen Hill and his mob partners Jimmy Conway and Tommy DeVito.",
        release_date: "1990-09-19",
        duration_minutes: 146,
        rating: 8.7,
        poster_url: "https://m.media-amazon.com/images/M/MV5BY2NkZjEzMDgtN2RjYy00YzM1LWI4ZmQtMjIwYjFjNmI3ZGEwXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_.jpg",
        genres: [genreIds[0], genreIds[1]], // Drama, Crime
        actors: [actorIds[3]], // Al Pacino
        directors: [directorIds[3]] // Quentin Tarantino
      }
    ];

    for (const movie of sampleMovies) {
      // Insert movie
      const movieResult = await db.query(
        `INSERT INTO movies (title, description, release_date, duration_minutes, rating, poster_url)
         VALUES ($1, $2, $3, $4, $5, $6) RETURNING movie_id`,
        [
          movie.title,
          movie.description,
          movie.release_date,
          movie.duration_minutes,
          movie.rating,
          movie.poster_url
        ]
      );
      
      const movieId = movieResult.rows[0].movie_id;
      console.log(`Added: ${movie.title}`);
      
      // Link genres
      for (const genreId of movie.genres) {
        await db.query(
          "INSERT INTO movie_genres (movie_id, genre_id) VALUES ($1, $2)",
          [movieId, genreId]
        );
      }
      
      // Link actors
      for (const actorId of movie.actors) {
        await db.query(
          "INSERT INTO movie_actors (movie_id, actor_id) VALUES ($1, $2)",
          [movieId, actorId]
        );
      }
      
      // Link directors
      for (const directorId of movie.directors) {
        await db.query(
          "INSERT INTO movie_directors (movie_id, director_id) VALUES ($1, $2)",
          [movieId, directorId]
        );
      }
    }

    console.log("Database seeded successfully!");
    process.exit(0);
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  }
}

seedDatabase();