#!/bin/bash

# CineMaster Pro - Setup Script
# Run this script to set up the entire project

echo "🎬 CineMaster Pro - Setup Script"
echo "================================="
echo ""

# Check Node.js
echo "Checking Node.js installation..."
if command -v node &> /dev/null; then
    NODE_VERSION=$(node --version)
    echo "✅ Node.js $NODE_VERSION found"
else
    echo "❌ Node.js not found. Please install Node.js 16+ from https://nodejs.org"
    exit 1
fi

# Check PostgreSQL
echo "Checking PostgreSQL..."
if command -v psql &> /dev/null; then
    PG_VERSION=$(psql --version)
    echo "✅ PostgreSQL found: $PG_VERSION"
else
    echo "⚠️ PostgreSQL not found in PATH. Make sure it's installed."
fi

echo ""
echo "📦 Installing Backend Dependencies..."
cd movie-management-backend

if [ ! -f .env ]; then
    echo "Creating .env file from .env.example..."
    cp .env.example .env
    echo "⚠️ Please update .env with your database credentials!"
fi

npm install
if [ $? -eq 0 ]; then
    echo "✅ Backend dependencies installed"
else
    echo "❌ Backend installation failed"
    exit 1
fi

# Create logs directory
if [ ! -d "logs" ]; then
    mkdir logs
    echo "✅ Created logs directory"
fi

cd ..

echo ""
echo "📦 Installing Frontend Dependencies..."
cd movie-management-frontend

if [ ! -f .env ]; then
    echo "Creating .env file from .env.example..."
    cp .env.example .env
fi

npm install
if [ $? -eq 0 ]; then
    echo "✅ Frontend dependencies installed"
else
    echo "❌ Frontend installation failed"
    exit 1
fi

cd ..

echo ""
echo "🎉 Setup Complete!"
echo ""
echo "📝 Next Steps:"
echo "1. Update movie-management-backend/.env with your database credentials"
echo "2. Create the database: CREATE DATABASE movie_management;"
echo "3. Run database migrations/seed if available"
echo "4. Start backend: cd movie-management-backend && npm run dev"
echo "5. Start frontend: cd movie-management-frontend && npm run dev"
echo ""
echo "🌐 URLs:"
echo "Backend:  http://localhost:5000"
echo "Frontend: http://localhost:5173"
echo ""
echo "Happy Movie Managing! 🎬🍿"
