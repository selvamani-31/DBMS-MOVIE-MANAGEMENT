# Deployment Instructions for CineMaster Pro

## Overview
This document explains how to deploy the CineMaster Pro movie management application to make it accessible to others on the internet.

## Prerequisites
1. GitHub account
2. Render account (for backend)
3. Netlify account (for frontend)
4. Neon account (for database)

## Step-by-Step Deployment

### 1. Database Setup (Neon)

1. Go to [Neon](https://neon.tech/) and create a free account
2. Create a new PostgreSQL database
3. Note down the following connection details:
   - Host
   - Database name
   - User
   - Password
   - Port (usually 5432)

### 2. Backend Deployment (Render)

1. Fork this repository to your GitHub account
2. Go to [Render](https://render.com/) and create a free account
3. Click "New+" → "Web Service"
4. Connect your GitHub repository
5. Configure the service:
   - Name: `cinemaster-backend`
   - Environment: `Node`
   - Build command: `npm install`
   - Start command: `npm start`
   - Root directory: `movie-management-backend`
6. Add environment variables:
   - `NODE_ENV`: `production`
   - `DB_USER`: Your Neon database user
   - `DB_HOST`: Your Neon database host
   - `DB_NAME`: Your Neon database name
   - `DB_PASSWORD`: Your Neon database password
   - `DB_PORT`: `5432`
   - `JWT_SECRET`: A random secure string
   - `TMDB_API_KEY`: Your TMDB API key (get one at https://www.themoviedb.org/settings/api)
   - `CORS_ORIGIN`: Your frontend URL (e.g., `https://your-app.netlify.app`)
7. Click "Create Web Service"

### 3. Frontend Deployment (Netlify)

1. Build the frontend locally:
   ```bash
   cd movie-management-frontend
   npm install
   npm run build
   ```
2. Go to [Netlify](https://netlify.com/) and create a free account
3. Drag and drop the `dist` folder from `movie-management-frontend` to Netlify
4. Or connect your GitHub repository:
   - Click "New site from Git"
   - Select your repository
   - Configure:
     - Base directory: `movie-management-frontend`
     - Build command: `npm run build`
     - Publish directory: `dist`
5. Add environment variables in Netlify settings:
   - `VITE_API_URL`: Your Render backend URL (e.g., `https://your-backend.onrender.com/api`)

### 4. Final Configuration

1. Once your Render backend is deployed, update the `CORS_ORIGIN` environment variable with your Netlify URL
2. Redeploy the backend for the CORS changes to take effect

## Testing

1. Visit your Netlify frontend URL
2. Try registering a new account
3. Try adding a movie using the auto-fetch feature
4. Verify that all features work correctly

## Troubleshooting

### Common Issues

1. **CORS errors**: Ensure `CORS_ORIGIN` in Render matches your Netlify URL exactly
2. **Database connection errors**: Verify all database environment variables are correct
3. **API not accessible**: Check Render logs for backend errors
4. **Movie auto-fetch not working**: Ensure `TMDB_API_KEY` is set correctly

### Checking Logs

1. **Render**: Go to your service dashboard and click "Logs"
2. **Netlify**: Go to your site dashboard and click "Deploys" then "Functions"

## Updating the Application

To update your deployed application:

1. Push changes to your GitHub repository
2. For frontend changes: Trigger a new deploy on Netlify
3. For backend changes: Trigger a new deploy on Render

## Cost

All services used (Render, Netlify, Neon) offer free tiers that are sufficient for this application:
- Render: Free web service with some limitations on sleep time
- Netlify: Generous free tier for static sites
- Neon: Free PostgreSQL database with reasonable limits

## Support

For issues with deployment, check the logs first. If you need help, you can:
1. Check the README.md for setup instructions
2. Review the code in the repository
3. Open an issue on GitHub if you find a bug