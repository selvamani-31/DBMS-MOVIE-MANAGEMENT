# 📦 Installation Guide - CineMaster Pro v2.0

## Step-by-Step Installation

### Prerequisites Check ✅

Before starting, ensure you have:
- ✅ Node.js 16 or higher
- ✅ PostgreSQL 12 or higher
- ✅ npm or yarn package manager

**Check versions:**
```bash
node --version    # Should be v16.x or higher
npm --version     # Should be 8.x or higher
psql --version    # Should be 12.x or higher
```

---

## 🎯 Installation Methods

### Method 1: Automated Setup (Recommended)

#### Windows (PowerShell)
```powershell
# Navigate to project folder
cd "c:\Users\Dharanesh E\movie"

# Run setup script
.\setup.ps1
```

#### Linux/Mac
```bash
# Navigate to project folder
cd ~/movie

# Make script executable
chmod +x setup.sh

# Run setup script
./setup.sh
```

The script will:
- ✅ Check Node.js installation
- ✅ Install backend dependencies
- ✅ Install frontend dependencies
- ✅ Create necessary directories
- ✅ Copy .env.example to .env

---

### Method 2: Manual Installation

#### Backend Installation

```bash
# Navigate to backend
cd movie-management-backend

# Install dependencies
npm install

# This installs:
# - express (^5.1.0)
# - pg (^8.16.3)
# - bcryptjs (^3.0.2)
# - jsonwebtoken (^9.0.2)
# - cors (^2.8.5)
# - dotenv (^17.2.3)
# - helmet (^7.1.0)              # NEW
# - express-rate-limit (^7.4.0)  # NEW
# - joi (^17.13.3)                # NEW
# - winston (^3.14.2)             # NEW
# - morgan (^1.10.0)              # NEW
# - express-validator (^7.0.1)   # NEW

# Install dev dependencies
npm install --save-dev nodemon
```

#### Frontend Installation

```bash
# Navigate to frontend
cd movie-management-frontend

# Install dependencies
npm install

# This installs:
# - react (^18.2.0)
# - react-dom (^18.2.0)
# - axios (^1.6.0)
# - react-hot-toast (^2.4.1)      # NEW
# - react-router-dom (^6.26.0)    # NEW
# - @vitejs/plugin-react (^4.2.0)
# - vite (^5.0.0)
```

---

## 🔧 Post-Installation Configuration

### 1. Backend Configuration

#### Create .env file
```bash
cd movie-management-backend
cp .env.example .env
```

#### Edit .env file
```env
# Database Configuration
DB_USER=postgres
DB_HOST=localhost
DB_NAME=movie_management
DB_PASSWORD=YOUR_PASSWORD_HERE    # ⚠️ CHANGE THIS
DB_PORT=5432

# Server Configuration
PORT=5000
NODE_ENV=development

# Security
JWT_SECRET=YOUR_SECRET_KEY_HERE   # ⚠️ CHANGE THIS
CORS_ORIGIN=http://localhost:5173

# Logging
LOG_LEVEL=debug
```

#### Create logs directory
```bash
mkdir logs
```

### 2. Database Setup

```sql
-- Connect to PostgreSQL
psql -U postgres

-- Create database
CREATE DATABASE movie_management;

-- Connect to database
\c movie_management

-- Run your schema/seed file if you have one
-- \i path/to/schema.sql
```

### 3. Frontend Configuration

#### Create .env file (Optional)
```bash
cd movie-management-frontend
cp .env.example .env
```

#### Edit .env file
```env
VITE_API_URL=http://localhost:5000/api
```

---

## ✅ Verification Steps

### 1. Verify Backend Installation

```bash
cd movie-management-backend

# Check installed packages
npm list --depth=0

# Expected output should include:
# ├── bcryptjs@3.0.2
# ├── cors@2.8.5
# ├── dotenv@17.2.3
# ├── express@5.1.0
# ├── express-rate-limit@7.4.0    ✨ NEW
# ├── express-validator@7.0.1     ✨ NEW
# ├── helmet@7.1.0                ✨ NEW
# ├── joi@17.13.3                 ✨ NEW
# ├── jsonwebtoken@9.0.2
# ├── morgan@1.10.0               ✨ NEW
# ├── pg@8.16.3
# └── winston@3.14.2              ✨ NEW

# Test backend startup
npm run dev
# Should see: ✅ Backend server running on port 5000
```

### 2. Verify Frontend Installation

```bash
cd movie-management-frontend

# Check installed packages
npm list --depth=0

# Expected output should include:
# ├── axios@1.6.0
# ├── react@18.2.0
# ├── react-dom@18.2.0
# ├── react-hot-toast@2.4.1       ✨ NEW
# └── react-router-dom@6.26.0     ✨ NEW

# Test frontend startup
npm run dev
# Should see: Local: http://localhost:5173/
```

---

## 🚨 Troubleshooting

### Issue 1: PowerShell Execution Policy Error

**Error:**
```
cannot be loaded because running scripts is disabled on this system
```

**Solution:**
```powershell
# Run PowerShell as Administrator
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser

# Then try again
.\setup.ps1
```

### Issue 2: npm install fails

**Error:**
```
npm ERR! code EACCES
```

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Remove node_modules and package-lock.json
rm -rf node_modules package-lock.json

# Install again
npm install
```

### Issue 3: Database Connection Failed

**Error:**
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```

**Solution:**
```bash
# Check PostgreSQL is running
# Windows:
services.msc  # Look for PostgreSQL service

# Linux/Mac:
sudo systemctl status postgresql
# or
brew services list
```

### Issue 4: Port Already in Use

**Error:**
```
Error: listen EADDRINUSE: address already in use :::5000
```

**Solution:**
```bash
# Windows:
netstat -ano | findstr :5000
taskkill /PID <PID> /F

# Linux/Mac:
lsof -ti:5000 | xargs kill -9

# Or use different port in .env
PORT=5001
```

### Issue 5: Module Not Found

**Error:**
```
Error: Cannot find module 'winston'
```

**Solution:**
```bash
# Navigate to backend
cd movie-management-backend

# Install specific package
npm install winston

# Or reinstall all
npm install
```

---

## 🔍 Verify Installation Success

### Backend Health Check
```bash
# With backend running
curl http://localhost:5000/health

# Expected response:
{
  "status": "OK",
  "message": "Movie Management API is running",
  "timestamp": "2025-10-19T...",
  "environment": "development",
  "version": "2.0.0"
}
```

### Frontend Access
1. Open browser: http://localhost:5173
2. Should see CineMaster Pro interface
3. Click "Login" - modal should appear
4. No console errors

### Check Logs
```bash
# Backend logs should exist
ls movie-management-backend/logs/
# Should see: combined.log, error.log
```

---

## 📊 What Gets Installed

### New Backend Packages (6)

1. **helmet** (7.1.0)
   - Sets security HTTP headers
   - Size: ~25 KB

2. **express-rate-limit** (7.4.0)
   - Prevents brute force attacks
   - Size: ~12 KB

3. **joi** (17.13.3)
   - Schema validation
   - Size: ~145 KB

4. **winston** (3.14.2)
   - Professional logging
   - Size: ~200 KB

5. **morgan** (1.10.0)
   - HTTP request logger
   - Size: ~8 KB

6. **express-validator** (7.0.1)
   - Additional validation helpers
   - Size: ~95 KB

**Total Backend Size Increase:** ~485 KB

### New Frontend Packages (2)

1. **react-hot-toast** (2.4.1)
   - Toast notifications
   - Size: ~18 KB

2. **react-router-dom** (6.26.0)
   - Client-side routing
   - Size: ~55 KB

**Total Frontend Size Increase:** ~73 KB

---

## 🎯 Installation Checklist

- [ ] Node.js 16+ installed
- [ ] PostgreSQL installed and running
- [ ] Backend dependencies installed
- [ ] Frontend dependencies installed
- [ ] .env files configured
- [ ] Database created
- [ ] logs/ directory created
- [ ] Backend starts without errors
- [ ] Frontend starts without errors
- [ ] Can access http://localhost:5173
- [ ] Can access http://localhost:5000/health
- [ ] No console errors

---

## 🚀 Next Steps After Installation

1. **Test the application:**
   - Register a new user
   - Login
   - Add a movie
   - Browse movies
   - Search movies

2. **Check logs:**
   ```bash
   tail -f movie-management-backend/logs/combined.log
   ```

3. **Explore new features:**
   - Toast notifications
   - Loading skeletons
   - Search functionality
   - Pagination

4. **Read documentation:**
   - README.md - Full documentation
   - QUICKSTART.md - Quick reference
   - UPGRADE_SUMMARY.md - What's new
   - BEFORE_AFTER_COMPARISON.md - Code improvements

---

## 📞 Need Help?

If you encounter issues:

1. Check this guide's troubleshooting section
2. Review error messages in:
   - Terminal output
   - Browser console (F12)
   - Backend logs (logs/error.log)
3. Verify all prerequisites are met
4. Try manual installation method

---

**Installation complete! 🎉 Start building amazing movie collections! 🎬**
