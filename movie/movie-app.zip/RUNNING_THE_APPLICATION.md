# ▶️ Running CineMaster Pro v2.0

## 🚀 Quick Start

1. **Start the Backend Server**:
   ```bash
   cd movie-management-backend
   npm start
   ```

2. **Start the Frontend Server** (in a new terminal):
   ```bash
   cd movie-management-frontend
   npm run dev
   ```

3. **Access the Application**:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:5000/api
   - Health Check: http://localhost:5000/health

## 🛠️ PowerShell Scripts (Alternative Method)

We've created PowerShell scripts to make running the application easier:

1. **Start Both Servers**:
   ```powershell
   .\start-servers.ps1
   ```

2. **Test Backend Only**:
   ```powershell
   .\test-backend.ps1
   ```

3. **Test Frontend Only**:
   ```powershell
   .\test-frontend.ps1
   ```

4. **Test Connection Between Frontend and Backend**:
   ```powershell
   .\test-connection.ps1
   ```

## 📋 Manual Testing with PowerShell

You can also test the API manually using PowerShell:

```powershell
# Test if backend is running
Invoke-RestMethod http://localhost:5000/health

# Get all movies
Invoke-RestMethod http://localhost:5000/api/movies

# Get API information
Invoke-RestMethod http://localhost:5000/api
```

## 🔧 Troubleshooting

### If you get "Failed to connect to backend" error:

1. **Check if backend is running**:
   - Look at the terminal where you started the backend
   - You should see: "✅ Backend server running on port 5000"

2. **Verify ports**:
   - Backend: http://localhost:5000
   - Frontend: http://localhost:3000

3. **Hard refresh the browser**:
   - Press Ctrl+Shift+R to clear cache

4. **Check CORS configuration**:
   - Backend [.env](file:///c:/Users/Dharanesh%20E/movie/movie-management-backend/.env) should have: `CORS_ORIGIN=http://localhost:3000`

### If you get PowerShell execution policy errors:

Run this command as Administrator:
```powershell
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

## 🎉 You're All Set!

Once both servers are running, you can:
- Browse movies at http://localhost:3000
- Register/Login to add/delete movies
- View API documentation at http://localhost:5000/api

Enjoy your upgraded CineMaster Pro v2.0 movie management system!